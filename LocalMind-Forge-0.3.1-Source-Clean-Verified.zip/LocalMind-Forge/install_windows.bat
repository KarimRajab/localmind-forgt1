@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Creating virtual environment...
py -3 -m venv .venv
if errorlevel 1 (
  echo Python 3 is not installed or the py launcher was not found.
  echo Install Python 3.11 or newer from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Installation failed. Check your internet connection and Python installation.
  echo Read the error above and check README.md for supported dependencies.
  pause
  exit /b 1
)
echo.
echo Installation complete. Run run_windows.bat
echo.
pause
