@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ==========================================================
echo LocalMind - Model-free Windows EXE build
echo Build this on a Windows PC. Python 3.11 x64 is recommended.
echo ==========================================================
where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python Launcher 'py' was not found.
  echo Install 64-bit Python 3.11 from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
if not exist .venv-build\Scripts\python.exe (
  py -3.11 -m venv .venv-build
  if errorlevel 1 (
    echo ERROR: Python 3.11 x64 was not found. Install it and retry.
    pause
    exit /b 1
  )
)
call .venv-build\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto :failed
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto :failed
python -m unittest discover -s tests -v
if errorlevel 1 goto :failed
python -m PyInstaller --noconfirm --clean LocalMind.spec
if errorlevel 1 goto :failed
if not exist dist\LocalMind\data mkdir dist\LocalMind\data
if not exist dist\LocalMind\workspace mkdir dist\LocalMind\workspace
echo.
echo BUILD COMPLETE: dist\LocalMind\LocalMind.exe
echo No AI model is required. All memory and knowledge data stay in data\
echo App data will be saved beside the executable in data\ and workspace\.
echo Note: this output is a folder distribution; zip the entire dist\LocalMind folder to share it.
echo.
pause
exit /b 0
:failed
echo.
echo BUILD FAILED. Review the first error above and install the missing dependency.
pause
exit /b 1
