# دليل بناء إصدار Windows وAndroid — LocalMind Forge 0.3.0

## Windows EXE

- النظام: Windows 10/11 x64.
- Python: 3.11 x64 (مستحسن) مع `py` Launcher.
- شغّل `build_windows_exe.bat` من جذر المشروع.
- الناتج المتوقع: `dist\LocalMind\LocalMind.exe` مع المجلد كله واعتماداته.
- اختبارات المصدر تعمل عبر `python -m unittest discover -s tests -v`.

يجب بناء EXE على Windows نفسه؛ PyInstaller ليس أداة cross-compiler. لم يتم إنشاء ملف EXE داخل بيئة Linux الحالية ولم يُختبر الناتج على Windows.

## Android APK

التوافق المحدد في ملفات Gradle هو Android Gradle Plugin 8.9.1، الذي يتطلب Gradle 8.11.1 أو أحدث وJDK 17 حسب جدول التوافق الرسمي. افتح المشروع باستخدام نسخة Android Studio حديثة تسمح بمزامنة هذه الإصدارات.

- Android Studio حديث، JDK 17، Android SDK Platform 35، Gradle مدعوم من Android Gradle Plugin.
- افتح مجلد `android/` في Android Studio.
- نفّذ Gradle Sync ثم Build > Build APK(s).
- الناتج المتوقع بعد نجاح البناء: `android/app/build/outputs/apk/debug/app-debug.apk` (حزمة debug قابلة للتثبيت محليًا).
- للبناء من CLI إذا كان Gradle متاحًا: `gradle --project-dir android assembleDebug`.
- مكتبة استخراج PDF هي `com.tom-roush:pdfbox-android:2.0.27.0`، وستنزل من Maven Central أثناء أول بناء.

لم يتوفر Android SDK أو Gradle أو اتصال شبكي أثناء إعداد الحزمة، لذا لم يتولد APK ولم يجر تشغيله على جهاز حقيقي. ملفات Android هي مشروع مصدر ينتظر بناؤه بالأدوات المناسبة، وليست APK متنكرًا.

## ما الذي يلزم قبل اعتبار الإصدار جاهزًا للتوزيع؟

1. تنفيذ بناء Windows وAPK في النظامين المستهدفين.
2. تثبيت APK على هاتف Android فعلي وتجربة أذونات منتقي الملفات وفهرسة مجلد.
3. اختبار استيراد PDF وDOCX/XLSX/PPTX كبير الحجم؛ PDF المصور يحتاج OCR إضافيًا.
4. بناء اختبار قبول يدوي لبيانات عربية ضخمة وتجربة البحث دون اتصال.
5. توقيع APK بمفتاح إصدار عند الحاجة لتوزيعه العام، والاحتفاظ بالمفتاح بأمان.
