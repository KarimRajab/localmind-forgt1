# PyInstaller spec for a model-free Windows onedir build.
# Build on Windows with: .venv-build\\Scripts\\python -m PyInstaller --noconfirm LocalMind.spec
from pathlib import Path

analysis = Analysis(
    ["main.py"],
    pathex=[str(Path.cwd())],
    binaries=[],
    datas=[],
    hiddenimports=["pypdf", "docx", "openpyxl", "pptx", "ebooklib", "bs4", "requests"],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["pytest", "tests", "llama_cpp", "torch", "tensorflow", "transformers"],
    noarchive=False,
    optimize=1,
)
pyz = PYZ(analysis.pure)
exe = EXE(
    pyz, analysis.scripts, [], exclude_binaries=True, name="LocalMind",
    debug=False, bootloader_ignore_signals=False, strip=False, upx=False,
    console=False, disable_windowed_traceback=False, argv_emulation=False,
    target_arch=None, codesign_identity=None, entitlements_file=None,
)
coll = COLLECT(exe, analysis.binaries, analysis.datas, strip=False, upx=False, upx_exclude=[], name="LocalMind")
