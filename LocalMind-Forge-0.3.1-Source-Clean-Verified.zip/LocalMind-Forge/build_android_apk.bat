@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0android"
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle is not installed or not on PATH.
  echo Open the android folder in Android Studio, sync Gradle, then use Build ^> Build APK(s).
  pause
  exit /b 2
)
gradle --no-daemon assembleDebug
if errorlevel 1 goto :failed
if exist app\build\outputs\apk\debug\app-debug.apk (
  echo BUILD COMPLETE: app\build\outputs\apk\debug\app-debug.apk
  exit /b 0
)
echo APK not found at expected path.
exit /b 3
:failed
echo Build failed. Review the Gradle output above.
pause
exit /b 1
