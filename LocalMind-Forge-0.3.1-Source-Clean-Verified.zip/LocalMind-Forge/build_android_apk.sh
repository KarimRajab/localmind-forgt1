#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/android"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Open the android/ folder in Android Studio, sync Gradle, then Build > Build APK(s)."
  exit 2
fi
gradle --no-daemon assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
if [[ -f "$APK" ]]; then
  echo "BUILD COMPLETE: $APK"
else
  echo "Build task finished but APK was not found at $APK" >&2
  exit 3
fi
