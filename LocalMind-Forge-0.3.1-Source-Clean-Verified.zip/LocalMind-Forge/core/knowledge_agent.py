"""Model-free local knowledge assistant.

This module deliberately uses no LLM, model weights, AI API, embedding service,
or remote inference server. It can retrieve and rank local material, store explicit
memories, and show source excerpts. It does not pretend to generate semantic
understanding beyond deterministic retrieval and simple rules.
"""
from __future__ import annotations

import re
import os
import sys
import subprocess
import webbrowser
from pathlib import Path
from dataclasses import dataclass
from typing import Iterable

from core.files import extract_text
from core.webtools import web_search

_ARABIC_DIACRITICS = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]")
_TOKEN_RE = re.compile(r"[\w\u0600-\u06FF]+", re.UNICODE)
_STOP_WORDS = {
    "من", "الى", "إلى", "عن", "على", "في", "ما", "ماذا", "كيف", "هل", "هو", "هي",
    "هذا", "هذه", "ذلك", "تلك", "مع", "كان", "تكون", "يكون", "هناك", "انا", "أنا",
    "انت", "أنت", "اريد", "أريد", "ممكن", "فضلا", "لو", "سمحت", "ماهو", "ماهي", "التي",
    "الذي", "الذين", "اللاتي", "the", "and", "or", "is", "are", "a", "an", "to", "of", "in",
    "on", "for", "with", "what", "how", "does", "do", "it", "this", "that", "please",
}


def normalize(text: str) -> str:
    text = _ARABIC_DIACRITICS.sub("", text or "")
    return (text.replace("ـ", "").replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
            .replace("ٱ", "ا").replace("ى", "ي").lower())


def tokens(text: str) -> list[str]:
    result = []
    for token in _TOKEN_RE.findall(normalize(text)):
        if len(token) >= 2 and token not in _STOP_WORDS and token not in result:
            result.append(token)
    return result[:40]


def _score(text: str, query_tokens: Iterable[str], query: str = "") -> float:
    cleaned = normalize(text)
    q = list(query_tokens)
    if not q:
        return 0.0
    present = [t for t in q if t in cleaned]
    if not present:
        return 0.0
    # Reward terms appearing more than once, without letting long chunks dominate.
    density = sum(min(3, cleaned.count(t)) * (1.0 + min(len(t), 12) / 30.0) for t in present)
    coverage = len(present) / max(1, len(q))
    exact = 2.0 if normalize(query).strip() and normalize(query).strip() in cleaned else 0.0
    return density / max(1.0, len(cleaned) ** 0.20) + coverage * 2.8 + exact


@dataclass
class Evidence:
    title: str
    path: str
    chunk_no: int
    content: str
    score: float


class KnowledgeAgent:
    """A deterministic assistant centered on user-owned documents and notes."""
    def __init__(self, db, config: dict, status_callback=None):
        self.db = db
        self.config = config
        self.status_callback = status_callback or (lambda _: None)

    def answer(self, prompt: str) -> str:
        raw = (prompt or "").strip()
        if not raw:
            return "اكتب سؤالك أو أرفق ملفات لإضافتها إلى قاعدة المعرفة المحلية."
        low = normalize(raw)

        if low in {"/help", "مساعدة", "المساعدة", "ماذا تستطيع ان تفعل", "ماذا يمكنك ان تفعل"}:
            return self.help_text()
        if low.startswith("/status") or low in {"الحالة", "حالة النظام", "حالة البرنامج"}:
            return self.status_text()
        if low == "/exec" or low.startswith("/exec "):
            return self._execute_command(raw.partition(" ")[2].strip())
        if low == "/list" or low.startswith("/list "):
            return self._list_path(raw.partition(" ")[2].strip() or self.config.get("workspace_path", "."))
        if low.startswith("/read "):
            return self._read_path(raw.split(maxsplit=1)[1].strip())
        if low.startswith("/open "):
            return self._open_path(raw.split(maxsplit=1)[1].strip())
        if low.startswith("/browser "):
            return self._open_browser(raw.split(maxsplit=1)[1].strip())
        if low.startswith("/create "):
            return self._create_file(raw.split(maxsplit=1)[1])
        if low.startswith("/remember ") or low.startswith("احفظ في ذاكرتك ") or low.startswith("تذكر ان ") or low.startswith("تذكر أن "):
            return self._remember_from_prompt(raw)
        if low.startswith("/forget "):
            try:
                note_id = int(raw.split(maxsplit=1)[1])
            except (IndexError, ValueError):
                return "الصيغة: /forget رقم_الذاكرة"
            return "حُذفت الذاكرة." if self.db.forget_note(note_id) else "لا توجد ذاكرة بهذا الرقم."
        if low.startswith("/files") or low in {"ملفاتي", "الملفات المفهرسة", "قائمة الملفات"}:
            docs = self.db.list_documents()
            if not docs:
                return "قاعدة المعرفة فارغة. استخدم زر «إضافة / فهرسة ملفات» أولًا."
            return "الملفات الموجودة في قاعدة المعرفة المحلية:\n" + "\n".join(
                f"{i}. {d['title']}\n   {d['path']} | {d['file_size']:,} بايت" for i, d in enumerate(docs, 1)
            )
        if low.startswith("/notes") or low in {"ذكرياتي", "الذاكرة", "ما الذي تتذكره"}:
            notes = self.db.list_notes(100)
            if not notes:
                return "لا توجد ذكريات صريحة محفوظة بعد. اكتب /remember العنوان: المعلومة"
            return "الذكريات المحلية المحفوظة:\n" + "\n".join(f"#{n['id']} — {n['key']}: {n['value']}" for n in notes)
        if low.startswith("/web ") or any(k in low for k in ("ابحث على الانترنت", "ابحث على الإنترنت", "من الانترنت", "من الإنترنت", "على الويب", "بحث ويب", "اخر الاخبار", "آخر الأخبار")):
            query = raw.split(maxsplit=1)[1] if low.startswith("/web ") and len(raw.split(maxsplit=1)) > 1 else raw
            return self._web(query)
        if low.startswith("/search "):
            query = raw.split(maxsplit=1)[1]
            return self._retrieve(query)

        # The recent conversation is retained locally. Use notes and documents as
        # evidence, rather than treating chat history as authoritative facts.
        remembered = self.db.list_notes(250)
        q_tokens = tokens(raw)
        ranked_notes = []
        for note in remembered:
            score = _score(f"{note['key']} {note['value']}", q_tokens, raw)
            if score > 0.45:
                ranked_notes.append((score, note))
        ranked_notes.sort(key=lambda item: item[0], reverse=True)
        note_text = ""
        if ranked_notes:
            note_text = "\n".join(f"- {n['key']}: {n['value']} [ذاكرة رقم {n['id']}]" for _, n in ranked_notes[:4])

        local_answer = self._retrieve(raw, include_title=False, quiet=True)
        has_evidence = local_answer.startswith("مقاطع من قاعدة المعرفة المحلية") or local_answer.startswith("المصادر المحلية المطابقة")
        if has_evidence:
            if note_text:
                return "من ذاكرتك المحلية:\n" + note_text + "\n\n" + local_answer
            return local_answer
        if note_text:
            return "المعلومة المتاحة في ذاكرتك:\n" + note_text + "\n\nلا توجد مقاطع كافية من الملفات المفهرسة للإجابة عن بقية السؤال."

        # General info can use public web search without a cloud AI. Only the query
        # and connection metadata go to the search engine when web is enabled.
        if self.config.get("web_search_enabled", True):
            return self._web(raw, add_context=True)
        return ("لا أملك مادة محلية كافية للإجابة عن هذا السؤال. لم يتم العثور على معلومة "
                "في الملفات أو الذكريات المفهرسة. أضف المصادر ذات الصلة أو فعّل بحث الويب.\n\n" + self.help_text())

    def _execute_command(self, command: str) -> str:
        """Run an explicit user-entered shell command on desktop only.

        This method is reached only through the literal /exec command. Documents,
        retrieved excerpts, and web results are never dispatched as commands.
        """
        if not command:
            return "الصيغة: /exec الأمر الذي تريد تشغيله\nيُنفذ الأمر كما كتبته ضمن صلاحيات حساب المستخدم الحالي، ولا يمنح صلاحيات مسؤول تلقائيًا."
        if len(command) > 4000:
            return "الأمر أطول من الحد المسموح (4000 حرف)."
        workspace = Path(self.config.get("workspace_path", ".")).expanduser().resolve()
        try:
            workspace.mkdir(parents=True, exist_ok=True)
            completed = subprocess.run(
                command,
                shell=True,
                cwd=str(workspace),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=30,
                check=False,
            )
            output = (completed.stdout or "")
            if completed.stderr:
                output += ("\n" if output and not output.endswith("\n") else "") + "[stderr]\n" + completed.stderr
            output = output.strip()
            if not output:
                output = "(لم يطبع الأمر أي مخرجات.)"
            if len(output) > 16000:
                output = output[:16000] + "\n[تم اقتطاع المخرجات عند 16,000 حرف]"
            return f"الأمر: {command}\nرمز الخروج: {completed.returncode}\nمجلد التنفيذ: {workspace}\n\n{output}"
        except subprocess.TimeoutExpired as exc:
            partial = exc.stdout or b""
            if isinstance(partial, bytes):
                partial = partial.decode("utf-8", errors="replace")
            partial_text = str(partial)[:4000]
            return f"انتهت مهلة تنفيذ الأمر بعد 30 ثانية: {command}" + (f"\nالمخرجات حتى انتهاء المهلة:\n{partial_text}" if partial_text else "")
        except Exception as exc:
            return f"تعذّر تنفيذ الأمر: {type(exc).__name__}: {exc}"

    def _list_path(self, raw_path: str) -> str:
        path = Path(raw_path).expanduser().resolve()
        if not path.exists() or not path.is_dir():
            return f"المجلد غير موجود أو المسار ليس مجلدًا: {path}"
        try:
            entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.casefold()))[:200]
            lines = [f"محتويات المجلد: {path}"]
            for item in entries:
                if item.is_dir():
                    lines.append(f"[مجلد] {item.name}/")
                else:
                    try: size = item.stat().st_size
                    except OSError: size = 0
                    lines.append(f"[ملف] {item.name} — {size:,} بايت")
            return "\n".join(lines) if entries else f"المجلد فارغ: {path}"
        except OSError as exc:
            return f"تعذّر استعراض المجلد: {exc}"

    def _read_path(self, raw_path: str) -> str:
        path = Path(raw_path.strip().strip('"')).expanduser()
        if not path.is_file():
            return f"الملف غير موجود أو غير قابل للقراءة: {path}"
        try:
            content = extract_text(path)
            if not content.strip():
                return "الملف موجود لكن لم يُستخرج منه نص قابل للعرض."
            return f"محتوى الملف: {path}\n\n{content[:16000]}" + ("\n\n[تم اقتطاع المحتوى عند 16,000 حرف]" if len(content) > 16000 else "")
        except Exception as exc:
            return f"تعذّرت قراءة الملف: {type(exc).__name__}: {exc}"

    def _open_path(self, raw_path: str) -> str:
        path = Path(raw_path.strip().strip('"')).expanduser().resolve()
        if not path.exists():
            return f"المسار غير موجود: {path}"
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(path))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
            return f"أرسلت طلب فتح المسار للتطبيق الافتراضي: {path}"
        except Exception as exc:
            return f"تعذّر فتح المسار: {type(exc).__name__}: {exc}"

    def _open_browser(self, raw_url: str) -> str:
        from urllib.parse import urlparse
        url = raw_url.strip()
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            return "استخدم رابطًا كاملًا يبدأ بـ https:// أو http://"
        try:
            opened = webbrowser.open(url)
            return f"تم إرسال طلب فتح الرابط إلى متصفح النظام: {url}" if opened else f"تعذّر تأكيد فتح المتصفح. الرابط: {url}"
        except Exception as exc:
            return f"تعذّر فتح المتصفح: {exc}"

    def _create_file(self, specification: str) -> str:
        if ":" not in specification:
            return "الصيغة: /create اسم_الملف_النسبي: محتوى الملف"
        relative, content = specification.split(":", 1)
        relative = relative.strip()
        workspace = Path(self.config.get("workspace_path", ".")).expanduser().resolve()
        if not relative or Path(relative).is_absolute():
            return "استخدم اسم ملف نسبيًا داخل مساحة العمل، وليس مسارًا مطلقًا."
        target = (workspace / relative).resolve()
        try:
            target.relative_to(workspace)
        except ValueError:
            return "الكتابة مسموحة داخل مساحة العمل المحددة فقط."
        if target.exists():
            return "لن أكتب فوق ملف موجود. اختر اسمًا جديدًا."
        if len(content.encode("utf-8")) > 2_000_000:
            return "محتوى الملف أكبر من 2 MB."
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("x", encoding="utf-8", newline="") as handle:
                handle.write(content.lstrip())
            return f"تم إنشاء الملف محليًا: {target}"
        except Exception as exc:
            return f"تعذّر إنشاء الملف: {type(exc).__name__}: {exc}"

    def _remember_from_prompt(self, raw: str) -> str:
        value = raw
        for prefix in ("/remember", "احفظ في ذاكرتك", "تذكر ان", "تذكر أن"):
            if normalize(value).startswith(normalize(prefix)):
                value = value[len(prefix):].strip()
                break
        if ":" in value:
            key, content = value.split(":", 1)
        else:
            key, content = "معلومة من المستخدم", value
        content = content.strip()
        key = key.strip() or "معلومة من المستخدم"
        if not content:
            return "لم أحفظ شيئًا لأن محتوى المعلومة فارغ. الصيغة: /remember العنوان: المعلومة"
        self.db.remember(key[:150], content[:10000])
        return f"حُفظت المعلومة محليًا في الذاكرة تحت عنوان «{key}». يمكنك عرضها بكتابة /notes."

    def _retrieve(self, query: str, include_title: bool = True, quiet: bool = False) -> str:
        q_tokens = tokens(query)
        if not q_tokens:
            return "اكتب كلمات واضحة للبحث في الملفات، أو أرفق ملفات أولًا."
        try:
            # Ask DB for a broader candidate set so this model-free reranker can
            # sort by query coverage, exact phrase, and term density.
            rows = self.db.search_chunks(query, limit=80)
        except Exception as exc:
            return f"تعذّر البحث في قاعدة المعرفة: {type(exc).__name__}: {exc}"
        ranked = []
        for row in rows:
            text = str(row.get("content", ""))
            score = _score(f"{row.get('title','')} {text}", q_tokens, query)
            if score > 0:
                ranked.append((score, row))
        ranked.sort(key=lambda x: x[0], reverse=True)
        if not ranked:
            if quiet:
                return "لم أعثر على مقاطع محلية مطابقة للسؤال."
            return "لم أعثر على مقاطع مطابقة في قاعدة المعرفة المحلية. أضف الملفات ذات الصلة أو استخدم /web للبحث على الإنترنت."
        result = ["مقاطع من قاعدة المعرفة المحلية" if include_title else "المصادر المحلية المطابقة"]
        for idx, (_, row) in enumerate(ranked[:5], 1):
            content = str(row.get("content", "")).strip()
            result.append(f"\n{idx}. {row.get('title', 'ملف')} — المقطع {int(row.get('chunk_no', 0)) + 1}\n   المسار: {row.get('path', '')}\n   مقتطف المصدر:\n> {content[:1600].replace(chr(10), chr(10) + '> ')}")
        result.append("\nهذه مقتطفات حرفية مرتبة بحسب تطابق الكلمات والعبارات، وليست استنتاجًا مولّدًا. اقرأ المصدر الأصلي للتحقق من السياق الكامل.")
        return "\n".join(result)

    def _web(self, query: str, add_context: bool = False) -> str:
        if not self.config.get("web_search_enabled", True):
            return "بحث الويب معطّل من الإعدادات. فعّله لتشغيل البحث عند توفر الإنترنت."
        self.status_callback("يبحث عبر محرك ويب عام؛ لا يتم استخدام نموذج ذكاء اصطناعي خارجي…")
        result = web_search(query, limit=6)
        if result.startswith("تعذّر") or result.startswith("لم تُرجع"):
            return result + "\n\nلا يزال بإمكانك استخدام البحث في الملفات المحلية دون اتصال."
        if add_context:
            return ("لم أجد سندًا كافيًا في قاعدة المعرفة المحلية، لذلك بحثت في الويب. "
                    "هذه نتائج ومقتطفات من محرك البحث وليست ملخصًا مولّدًا:\n\n" + result)
        return result

    def help_text(self) -> str:
        return ("LocalMind — مساعد معرفة محلي بلا نموذج ذكاء اصطناعي\n\n"
                "• أرفق ملفًا أو مجلدًا من زر الفهرسة، ثم اسأل عن محتواه.\n"
                "• /search كلمات — بحث داخل الملفات المفهرسة.\n"
                "• /web كلمات — بحث على الويب عند الاتصال.\n"
                "• /remember العنوان: المعلومة — حفظ معلومة تعلّمني إياها في ذاكرة محلية.\n"
                "• /notes — عرض الذكريات المحفوظة.\n"
                "• /forget رقم — حذف ذاكرة.\n"
                "• /files — عرض الملفات المفهرسة.\n"
                "• /status — حالة النظام.\n"
                "• /exec الأمر — تشغيل أمر نظام كتبته صراحةً، ضمن صلاحيات الحساب الحالي؛ مجلد العمل الافتراضي workspace، المهلة 30 ثانية.\n"
                "• /list [مسار] — استعراض مجلد.\n"
                "• /read مسار — قراءة ملف نصي أو مستند مدعوم.\n"
                "• /open مسار — فتح ملف أو مجلد بالتطبيق الافتراضي.\n"
                "• /browser رابط — فتح الرابط في المتصفح.\n"
                "• /create اسم_نسبي: المحتوى — إنشاء ملف جديد داخل workspace.\n\n"
                "لا أستخدم API ذكاء اصطناعي ولا نموذجًا جاهزًا. لذلك أعثر على المعلومات وأقتبسها وأرتبها، لكنني لا أستطيع توليد لغة أو استنتاجات عامة كالإنسان من دون محرك استدلال مدرّب.")

    def status_text(self) -> str:
        docs = self.db.list_documents()
        notes = self.db.list_notes(100000)
        try:
            path = getattr(self.db, "path", "قاعدة محلية")
        except Exception:
            path = "قاعدة محلية"
        return ("**حالة LocalMind**\n"
                f"• المحرك: استرجاع حتمي بلا نموذج / API\n"
                f"• قاعدة البيانات: {path}\n"
                f"• عدد الملفات المفهرسة: {len(docs)}\n"
                f"• عدد الذكريات الصريحة: {len(notes)}\n"
                f"• بحث الويب مفعّل: {'نعم' if self.config.get('web_search_enabled', True) else 'لا'}\n"
                "• البيانات المحلية تبقى في مجلد data ما لم تنسخها أو تصدّرها يدويًا.")
