"""Consistent, streaming local backup/export for LocalMind's SQLite knowledge base."""
from __future__ import annotations
import hashlib
import json
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def create_backup(output_path: str | Path, db_path: str | Path, config_path: str | Path | None = None) -> Path:
    """Create a transaction-consistent ZIP snapshot without loading the DB into RAM."""
    output = Path(output_path).expanduser().resolve()
    database = Path(db_path).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if not database.is_file():
        raise FileNotFoundError(f"قاعدة البيانات غير موجودة: {database}")

    with tempfile.TemporaryDirectory(prefix="localmind-backup-") as temp_dir:
        snapshot = Path(temp_dir) / "memory.sqlite3"
        # SQLite's online backup API includes committed WAL pages and avoids a
        # byte-level copy of a live database.
        with sqlite3.connect(str(database), timeout=30) as source, sqlite3.connect(str(snapshot)) as target:
            source.backup(target, pages=256, sleep=0.05)
            integrity = target.execute("PRAGMA integrity_check").fetchone()[0]
            if integrity != "ok":
                raise RuntimeError(f"فشل التحقق من سلامة قاعدة البيانات: {integrity}")

        items: list[tuple[str, Path]] = [("data/memory.sqlite3", snapshot)]
        cfg = Path(config_path).expanduser() if config_path else None
        if cfg and cfg.is_file():
            items.append(("data/config.json", cfg))
        manifest = {
            "application": "LocalMind Forge",
            "format_version": 1,
            "created_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "description": "Local database backup. Indexed text, conversations, notes and optional configuration are included.",
            "files": {name: {"size": path.stat().st_size, "sha256": _sha256_file(path)} for name, path in items},
        }
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=4, allowZip64=True) as archive:
            for name, path in items:
                archive.write(path, arcname=name)
            archive.writestr("BACKUP-MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2))
            _write_portable_pack(archive, snapshot)
    return output


def _write_jsonl(archive: zipfile.ZipFile, name: str, connection: sqlite3.Connection, query: str, mapper) -> int:
    count = 0
    with archive.open(name, "w", force_zip64=True) as member:
        cursor = connection.execute(query)
        while True:
            rows = cursor.fetchmany(1000)
            if not rows:
                break
            for row in rows:
                item = mapper(dict(row))
                member.write((json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8"))
                count += 1
    return count


def _write_portable_pack(archive: zipfile.ZipFile, database_path: Path) -> None:
    """Write a streaming cross-platform knowledge pack alongside the local DB backup."""
    import uuid
    pack_id = "lm-" + uuid.uuid4().hex
    with sqlite3.connect(str(database_path)) as connection:
        connection.row_factory = sqlite3.Row
        note_count = connection.execute("SELECT COUNT(*) FROM notes").fetchone()[0]
        document_count = connection.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
        chunk_count = connection.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        portable_manifest = {
            "format": "localmind-portable-knowledge",
            "format_version": 1,
            "pack_id": pack_id,
            "created_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "counts": {"notes": note_count, "documents": document_count, "chunks": chunk_count},
            "note": "Contains extracted and indexed text, not original binary documents. Original files can be imported again if needed.",
        }
        archive.writestr("knowledge-pack/manifest.json", json.dumps(portable_manifest, ensure_ascii=False, indent=2))
        _write_jsonl(archive, "knowledge-pack/notes.jsonl", connection,
                     "SELECT id,key,value,created_at FROM notes ORDER BY id",
                     lambda r: {"id": r["id"], "title": r["key"], "content": r["value"], "created_at": r["created_at"]})
        _write_jsonl(archive, "knowledge-pack/documents.jsonl", connection,
                     "SELECT id,path,title,file_size,indexed_at FROM documents ORDER BY id",
                     lambda r: {"id": r["id"], "source": r["path"], "title": r["title"], "size_bytes": r["file_size"], "indexed_at": r["indexed_at"]})
        _write_jsonl(archive, "knowledge-pack/chunks.jsonl", connection,
                     "SELECT document_id,chunk_no,content FROM chunks ORDER BY document_id,chunk_no,id",
                     lambda r: {"document_id": r["document_id"], "chunk_no": r["chunk_no"], "content": r["content"]})


def import_knowledge_pack(path: str | Path, database) -> dict[str, int]:
    """Import text chunks and notes from a LocalMind backup ZIP, streaming rows."""
    with zipfile.ZipFile(Path(path).expanduser(), "r") as archive:
        names = set(archive.namelist())
        required = {"knowledge-pack/manifest.json", "knowledge-pack/notes.jsonl", "knowledge-pack/documents.jsonl", "knowledge-pack/chunks.jsonl"}
        if not required.issubset(names):
            raise ValueError("هذا ZIP لا يحتوي على حزمة معرفة LocalMind قابلة للاستيراد.")
        portable = json.loads(archive.read("knowledge-pack/manifest.json").decode("utf-8"))
        if portable.get("format") != "localmind-portable-knowledge" or portable.get("format_version") != 1:
            raise ValueError("صيغة حزمة المعرفة أو إصدارها غير مدعوم.")
        pack_id = str(portable.get("pack_id", "imported"))
        imported = {"notes": 0, "documents": 0, "chunks": 0}
        # Notes and document metadata are modest rows. The potentially huge chunks
        # table is inserted one JSON line at a time in bounded transactions.
        with database.connect() as con:
            for line in archive.open("knowledge-pack/notes.jsonl", "r"):
                record = json.loads(line.decode("utf-8"))
                key, value = str(record.get("title", "معلومة"))[:150], str(record.get("content", ""))[:10000]
                if not value:
                    continue
                exists = con.execute("SELECT 1 FROM notes WHERE key=? AND value=? LIMIT 1", (key, value)).fetchone()
                if not exists:
                    con.execute("INSERT INTO notes(key,value,created_at) VALUES(?,?,?)", (key, value, str(record.get("created_at") or _local_import_now())))
                    imported["notes"] += 1
            old_to_new: dict[str, int] = {}
            for line in archive.open("knowledge-pack/documents.jsonl", "r"):
                record = json.loads(line.decode("utf-8"))
                old_id = str(record.get("id", ""))
                if not old_id:
                    continue
                stable_path = f"localmind-pack://{pack_id}/{old_id}"
                con.execute("DELETE FROM documents WHERE path=?", (stable_path,))
                cur = con.execute(
                    "INSERT INTO documents(path,title,file_size,modified_at,indexed_at) VALUES(?,?,?,?,?)",
                    (stable_path, str(record.get("title", "مستند مستورد"))[:500], int(record.get("size_bytes", 0) or 0), 0.0, str(record.get("indexed_at") or _local_import_now()))
                )
                old_to_new[old_id] = int(cur.lastrowid)
                imported["documents"] += 1
            # Use smaller transactions so an interrupted very large import does
            # not leave one uncommitted transaction open for the whole archive.
            pending = 0
            for line in archive.open("knowledge-pack/chunks.jsonl", "r"):
                record = json.loads(line.decode("utf-8"))
                target_id = old_to_new.get(str(record.get("document_id", "")))
                content = str(record.get("content", ""))
                if target_id is None or not content:
                    continue
                con.execute("INSERT INTO chunks(document_id,chunk_no,content) VALUES(?,?,?)",
                            (target_id, int(record.get("chunk_no", 0)), content))
                imported["chunks"] += 1
                pending += 1
                if pending >= 500:
                    con.commit()
                    pending = 0
            con.commit()
        return imported


def _local_import_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def verify_backup(path: str | Path) -> dict:
    """Validate the archive manifest, file hashes, and SQLite integrity."""
    backup = Path(path).expanduser()
    with zipfile.ZipFile(backup, "r") as archive:
        damaged = archive.testzip()
        if damaged:
            raise ValueError(f"الملف المضغوط يحتوي على عنصر تالف: {damaged}")
        names = set(archive.namelist())
        if "BACKUP-MANIFEST.json" not in names or "data/memory.sqlite3" not in names:
            raise ValueError("ملف النسخة الاحتياطية لا يحتوي على الملفات المطلوبة.")
        manifest = json.loads(archive.read("BACKUP-MANIFEST.json").decode("utf-8"))
        with tempfile.TemporaryDirectory(prefix="localmind-verify-") as temp_dir:
            db_copy = Path(temp_dir) / "memory.sqlite3"
            for name, expected in manifest.get("files", {}).items():
                if name not in names:
                    raise ValueError(f"ملف مفقود داخل النسخة: {name}")
                info = archive.getinfo(name)
                if info.file_size != expected.get("size"):
                    raise ValueError(f"حجم الملف غير مطابق: {name}")
                digest = hashlib.sha256()
                target_path = db_copy if name == "data/memory.sqlite3" else None
                with archive.open(name, "r") as source:
                    if target_path:
                        with target_path.open("wb") as target:
                            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                                digest.update(chunk)
                                target.write(chunk)
                    else:
                        for chunk in iter(lambda: source.read(1024 * 1024), b""):
                            digest.update(chunk)
                if digest.hexdigest() != expected.get("sha256"):
                    raise ValueError(f"فشل التحقق من سلامة الملف: {name}")
            with sqlite3.connect(str(db_copy)) as db:
                result = db.execute("PRAGMA integrity_check").fetchone()[0]
                if result != "ok":
                    raise ValueError(f"قاعدة البيانات داخل النسخة غير سليمة: {result}")
        return manifest
