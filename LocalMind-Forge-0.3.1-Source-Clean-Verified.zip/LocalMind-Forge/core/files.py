from __future__ import annotations
import csv
import json
from pathlib import Path
from html.parser import HTMLParser

TEXT_EXTS = {
    ".txt", ".md", ".rst", ".py", ".json", ".jsonl", ".yaml", ".yml", ".toml", ".ini", ".cfg",
    ".csv", ".tsv", ".html", ".htm", ".xml", ".log", ".sql", ".js", ".ts", ".jsx", ".tsx",
    ".css", ".scss", ".c", ".h", ".cpp", ".hpp", ".cs", ".java", ".go", ".rs", ".sh", ".bat",
    ".ps1", ".php", ".rb", ".kt", ".swift", ".r", ".lua", ".env", ".gitignore", ".conf", ".properties"
}

class _HTMLText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.skip = 0
    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style", "noscript", "svg"}: self.skip += 1
    def handle_endtag(self, tag):
        if tag in {"script", "style", "noscript", "svg"} and self.skip: self.skip -= 1
    def handle_data(self, data):
        if not self.skip and data.strip(): self.parts.append(data.strip())


def extract_text(path: str | Path) -> str:
    p = Path(path)
    ext = p.suffix.lower()
    if not p.is_file():
        raise FileNotFoundError(f"الملف غير موجود: {p}")
    if p.stat().st_size > 80 * 1024 * 1024:
        raise ValueError("حجم الملف أكبر من الحد الافتراضي للفهرسة (80 MB).")
    if ext in TEXT_EXTS or (not ext and p.name.startswith(".")):
        raw = p.read_text(encoding="utf-8", errors="replace")
        if ext in {".html", ".htm", ".xml"}:
            parser = _HTMLText(); parser.feed(raw)
            return "\n".join(parser.parts)
        if ext == ".json":
            try: return json.dumps(json.loads(raw), ensure_ascii=False, indent=2)
            except json.JSONDecodeError: return raw
        if ext in {".csv", ".tsv"}:
            delim = "\t" if ext == ".tsv" else ","
            try:
                rows = list(csv.reader(raw.splitlines(), delimiter=delim))
                return "\n".join(" | ".join(cell for cell in row) for row in rows)
            except csv.Error:
                return raw
        return raw
    if ext == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError as e:
            raise RuntimeError("لفتح PDF ثبّت المتطلبات عبر install_windows.bat أو pip install -r requirements.txt") from e
        reader = PdfReader(str(p))
        return "\n\n".join((page.extract_text() or "") for page in reader.pages)
    if ext == ".docx":
        try: from docx import Document
        except ImportError as e: raise RuntimeError("لفتح DOCX ثبّت python-docx.") from e
        doc = Document(str(p))
        parts = [para.text for para in doc.paragraphs if para.text.strip()]
        for table in doc.tables:
            for row in table.rows:
                parts.append(" | ".join(cell.text.strip() for cell in row.cells))
        return "\n".join(parts)
    if ext == ".xlsx":
        try: import openpyxl
        except ImportError as e: raise RuntimeError("لفتح XLSX ثبّت openpyxl.") from e
        book = openpyxl.load_workbook(str(p), read_only=True, data_only=True)
        out = []
        for sheet in book.worksheets:
            out.append(f"[Sheet: {sheet.title}]")
            for row in sheet.iter_rows(values_only=True):
                vals = ["" if v is None else str(v) for v in row]
                if any(vals): out.append(" | ".join(vals))
        book.close()
        return "\n".join(out)
    if ext == ".pptx":
        try: from pptx import Presentation
        except ImportError as e: raise RuntimeError("لفتح PPTX ثبّت python-pptx.") from e
        pres = Presentation(str(p))
        out = []
        for i, slide in enumerate(pres.slides, 1):
            out.append(f"[Slide {i}]")
            for shape in slide.shapes:
                if getattr(shape, "has_text_frame", False) and shape.text.strip(): out.append(shape.text)
                if getattr(shape, "has_table", False):
                    for row in shape.table.rows: out.append(" | ".join(cell.text for cell in row.cells))
        return "\n".join(out)
    if ext == ".epub":
        try: from ebooklib import epub, ITEM_DOCUMENT
        except ImportError as e: raise RuntimeError("لفتح EPUB ثبّت EbookLib.") from e
        book = epub.read_epub(str(p))
        out = []
        for item in book.get_items_of_type(ITEM_DOCUMENT):
            parser = _HTMLText(); parser.feed(item.get_content().decode("utf-8", errors="replace"))
            out.extend(parser.parts)
        return "\n".join(out)
    raise ValueError(f"صيغة {ext or '(بدون امتداد)'} غير مدعومة بعد. جرّب PDF أو DOCX أو XLSX أو PPTX أو TXT أو CSV أو ملفات الكود.")


def index_file(db, path: str | Path) -> tuple[int, int]:
    p = Path(path).expanduser().resolve()
    text = extract_text(p)
    if not text.strip():
        raise ValueError("لم يُستخرج نص من الملف. قد يكون ملف PDF عبارة عن صور ممسوحة ضوئيًا أو بصيغة غير مدعومة.")
    chunks = db.index_document(str(p), p.name, text, p.stat().st_size, p.stat().st_mtime)
    return len(text), chunks
