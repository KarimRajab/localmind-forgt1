"""Core modules for LocalMind."""
