from __future__ import annotations
from urllib.parse import urlparse
import re

USER_AGENT = "LocalMind/0.3.0 (local knowledge assistant)"


def web_search(query: str, limit: int = 5) -> str:
    """Search the public web without using a commercial AI API."""
    try:
        import requests
        from bs4 import BeautifulSoup
    except ImportError:
        return "البحث على الويب يحتاج المكتبات: requests و beautifulsoup4. ثبّت requirements.txt."
    url = "https://html.duckduckgo.com/html/"
    try:
        response = requests.get(url, params={"q": query}, headers={"User-Agent": USER_AGENT}, timeout=15)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        results = []
        for item in soup.select(".result")[:max(1, min(limit, 8))]:
            a = item.select_one("a.result__a")
            snippet = item.select_one(".result__snippet")
            if a and a.get("href"):
                href = a.get("href", "")
                results.append(f"- {a.get_text(' ', strip=True)}\n  الرابط: {href}\n  المقتطف: {snippet.get_text(' ', strip=True) if snippet else 'لا يوجد مقتطف'}")
        if results:
            return "نتائج بحث ويب (راجع الروابط والمصادر الأصلية):\n" + "\n".join(results)
        return "لم تُرجع محرك البحث نتائج قابلة للاستخراج. جرّب عبارة أخرى أو افتح الموقع مباشرة."
    except Exception as e:
        return f"تعذّر تنفيذ البحث على الويب: {type(e).__name__}: {e}"


def fetch_url(url: str, max_chars: int = 14000) -> str:
    parsed = urlparse(url.strip())
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return "يجب أن يكون الرابط عنوان HTTP أو HTTPS كاملًا."
    try:
        import requests
        from bs4 import BeautifulSoup
        res = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=18, allow_redirects=True)
        res.raise_for_status()
        ctype = res.headers.get("content-type", "")
        if "text" not in ctype and "json" not in ctype and "xml" not in ctype:
            return f"الصفحة ليست محتوى نصيًا قابلًا للاستخراج (Content-Type: {ctype})."
        if "html" in ctype:
            soup = BeautifulSoup(res.text, "html.parser")
            for tag in soup(["script", "style", "nav", "footer", "noscript", "svg"]): tag.decompose()
            title = soup.title.get_text(" ", strip=True) if soup.title else url
            body = re.sub(r"\n{3,}", "\n\n", soup.get_text("\n", strip=True))
            return f"العنوان: {title}\nالرابط النهائي: {res.url}\n\n{body[:max_chars]}"
        return f"الرابط النهائي: {res.url}\n\n{res.text[:max_chars]}"
    except Exception as e:
        return f"تعذّر جلب الصفحة: {type(e).__name__}: {e}"
