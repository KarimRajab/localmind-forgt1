from __future__ import annotations
import json
import sys
from pathlib import Path

# Store mutable data next to a packaged release, and beside the source in dev mode.
if getattr(sys, "frozen", False):
    ROOT = Path(sys.executable).resolve().parent
else:
    ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
WORKSPACE_DIR = ROOT / "workspace"
CONFIG_PATH = DATA_DIR / "config.json"
DB_PATH = DATA_DIR / "memory.sqlite3"

DEFAULTS = {
    "workspace_path": str(WORKSPACE_DIR),
    "web_search_enabled": True,
    "max_file_size_mb": 80,
    "max_folder_files": 5000,
    "max_chunk_chars": 1400,
    "chunk_overlap_chars": 180,
}


def load_config() -> dict:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_PATH.exists():
        try:
            user = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            return {**DEFAULTS, **user}
        except (OSError, json.JSONDecodeError):
            pass
    save_config(DEFAULTS)
    return DEFAULTS.copy()


def save_config(config: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
