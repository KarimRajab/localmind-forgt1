from __future__ import annotations
import sqlite3
import re
from datetime import datetime, timezone
from pathlib import Path


class LocalDatabase:
    """SQLite-backed conversation history, long-term memory, and file index."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def connect(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA foreign_keys=ON")
        return con

    def _init_db(self):
        with self.connect() as con:
            con.executescript("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    thread_id TEXT NOT NULL DEFAULT 'main',
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_messages_thread_id ON messages(thread_id, id);
                CREATE TABLE IF NOT EXISTS documents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT NOT NULL UNIQUE,
                    title TEXT NOT NULL,
                    file_size INTEGER NOT NULL DEFAULT 0,
                    modified_at REAL NOT NULL DEFAULT 0,
                    indexed_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS chunks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
                    chunk_no INTEGER NOT NULL,
                    content TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_chunks_document ON chunks(document_id, chunk_no);
                CREATE TABLE IF NOT EXISTS notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT NOT NULL,
                    value TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
            """)
            try:
                # Full-text search for file chunks makes large local knowledge bases
                # scale much better than scanning every chunk with LIKE.
                existing_chunks_fts = con.execute("SELECT 1 FROM sqlite_master WHERE name='chunks_fts'").fetchone()
                if not existing_chunks_fts:
                    con.execute("CREATE VIRTUAL TABLE chunks_fts USING fts5(content, content='chunks', content_rowid='id', tokenize='unicode61')")
                    con.execute("INSERT INTO chunks_fts(chunks_fts) VALUES('rebuild')")
                con.executescript("""
                    CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
                      INSERT INTO chunks_fts(rowid, content) VALUES (new.id, new.content);
                    END;
                    CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
                      INSERT INTO chunks_fts(chunks_fts, rowid, content) VALUES('delete', old.id, old.content);
                    END;
                    CREATE TRIGGER IF NOT EXISTS chunks_au AFTER UPDATE ON chunks BEGIN
                      INSERT INTO chunks_fts(chunks_fts, rowid, content) VALUES('delete', old.id, old.content);
                      INSERT INTO chunks_fts(rowid, content) VALUES (new.id, new.content);
                    END;
                """)
            except sqlite3.OperationalError:
                # LIKE fallback remains available if this SQLite build lacks FTS5.
                pass

            try:
                existing_message_fts = con.execute("SELECT 1 FROM sqlite_master WHERE name='message_fts'").fetchone()
                if not existing_message_fts:
                    con.execute("CREATE VIRTUAL TABLE message_fts USING fts5(content, content='messages', content_rowid='id')")
                    con.execute("INSERT INTO message_fts(message_fts) VALUES('rebuild')")
                con.executescript("""
                    CREATE TRIGGER IF NOT EXISTS messages_ai AFTER INSERT ON messages BEGIN
                      INSERT INTO message_fts(rowid, content) VALUES (new.id, new.content);
                    END;
                    CREATE TRIGGER IF NOT EXISTS messages_ad AFTER DELETE ON messages BEGIN
                      INSERT INTO message_fts(message_fts, rowid, content) VALUES('delete', old.id, old.content);
                    END;
                """)
            except sqlite3.OperationalError:
                # SQLite builds without FTS5 still work using LIKE-based search.
                pass

    @staticmethod
    def now() -> str:
        return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")

    def add_message(self, role: str, content: str, thread_id: str = "main") -> int:
        with self.connect() as con:
            cur = con.execute(
                "INSERT INTO messages(thread_id, role, content, created_at) VALUES(?,?,?,?)",
                (thread_id, role, content, self.now()),
            )
            return int(cur.lastrowid)

    def recent_messages(self, limit: int = 16, thread_id: str = "main") -> list[dict]:
        with self.connect() as con:
            rows = con.execute(
                "SELECT role,content,created_at FROM messages WHERE thread_id=? ORDER BY id DESC LIMIT ?",
                (thread_id, limit),
            ).fetchall()
        return [dict(r) for r in reversed(rows)]

    def search_messages(self, query: str, limit: int = 5) -> list[dict]:
        tokens = list(dict.fromkeys(re.findall(r"[\w\u0600-\u06FF]{3,}", query, flags=re.UNICODE)))[:8]
        if not tokens:
            return []
        with self.connect() as con:
            try:
                fts_query = " OR ".join('"' + t.replace('"', '') + '"' for t in tokens)
                rows = con.execute(
                    "SELECT m.role,m.content,m.created_at FROM message_fts f JOIN messages m ON m.id=f.rowid "
                    "WHERE message_fts MATCH ? ORDER BY rank LIMIT ?", (fts_query, limit)
                ).fetchall()
            except sqlite3.OperationalError:
                clauses = " OR ".join("content LIKE ?" for _ in tokens)
                params = [f"%{t}%" for t in tokens] + [limit]
                rows = con.execute(
                    f"SELECT role,content,created_at FROM messages WHERE {clauses} ORDER BY id DESC LIMIT ?", params
                ).fetchall()
        return [dict(r) for r in rows]

    def remember(self, key: str, value: str) -> None:
        with self.connect() as con:
            con.execute("INSERT INTO notes(key,value,created_at) VALUES(?,?,?)", (key, value, self.now()))

    def list_notes(self, limit: int = 100) -> list[dict]:
        with self.connect() as con:
            rows = con.execute("SELECT id,key,value,created_at FROM notes ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def forget_note(self, note_id: int) -> bool:
        with self.connect() as con:
            cur = con.execute("DELETE FROM notes WHERE id=?", (note_id,))
            return cur.rowcount > 0

    def index_document(self, path: str, title: str, text: str, file_size: int, modified_at: float) -> int:
        chunks = []
        cleaned = text.strip()
        width, overlap = 1400, 180
        start = 0
        while start < len(cleaned):
            part = cleaned[start:start + width].strip()
            if part:
                chunks.append(part)
            start += width - overlap
        with self.connect() as con:
            con.execute("DELETE FROM documents WHERE path=?", (path,))
            cur = con.execute(
                "INSERT INTO documents(path,title,file_size,modified_at,indexed_at) VALUES(?,?,?,?,?)",
                (path, title, file_size, modified_at, self.now()),
            )
            doc_id = int(cur.lastrowid)
            con.executemany(
                "INSERT INTO chunks(document_id,chunk_no,content) VALUES(?,?,?)",
                [(doc_id, n, chunk) for n, chunk in enumerate(chunks)],
            )
            return len(chunks)

    def search_chunks(self, query: str, limit: int = 5) -> list[dict]:
        tokens = list(dict.fromkeys(re.findall(r"[\w\u0600-\u06FF]{2,}", query, flags=re.UNICODE)))[:24]
        if not tokens:
            return []
        safe_tokens = [t.replace('"', '') for t in tokens if t.strip('"')]
        if not safe_tokens:
            return []
        with self.connect() as con:
            try:
                fts_query = " OR ".join('"' + t + '"' for t in safe_tokens)
                rows = con.execute(
                    "SELECT d.title,d.path,c.content,c.chunk_no,bm25(chunks_fts) AS score "
                    "FROM chunks_fts JOIN chunks c ON c.id=chunks_fts.rowid "
                    "JOIN documents d ON d.id=c.document_id "
                    "WHERE chunks_fts MATCH ? ORDER BY score LIMIT ?", (fts_query, max(1, min(int(limit), 500)))).fetchall()
                if rows:
                    return [dict(r) for r in rows]
            except sqlite3.OperationalError:
                pass
            # Fallback for SQLite builds without FTS5, also preserve ranked candidates.
            clauses = " OR ".join("lower(c.content) LIKE ?" for _ in safe_tokens)
            params = [f"%{t.lower()}%" for t in safe_tokens] + [max(1, min(int(limit), 500)) * 8]
            rows = con.execute(
                "SELECT d.title,d.path,c.content,c.chunk_no FROM chunks c JOIN documents d ON d.id=c.document_id "
                f"WHERE {clauses} ORDER BY c.id DESC LIMIT ?", params).fetchall()
            candidates = [dict(r) for r in rows]
        # Stable lightweight re-ranking by query coverage and density.
        qnorm = query.lower()
        scored = []
        for row in candidates:
            content = str(row.get("content", "")).lower()
            title = str(row.get("title", "")).lower()
            matched = sum(1 for token in safe_tokens if token.lower() in content or token.lower() in title)
            density = sum(min(3, content.count(token.lower())) for token in safe_tokens)
            phrase = 2 if qnorm and qnorm in content else 0
            score = matched / len(safe_tokens) * 4 + density / max(1, len(content)) ** 0.15 + phrase
            row["score"] = score
            scored.append(row)
        scored.sort(key=lambda r: r["score"], reverse=True)
        return scored[:max(1, min(int(limit), 500))]

    def get_messages(self, thread_id: str = "main", limit: int = 500) -> list[dict]:
        with self.connect() as con:
            rows = con.execute(
                "SELECT role,content,created_at FROM messages WHERE thread_id=? ORDER BY id ASC LIMIT ?",
                (thread_id, limit),
            ).fetchall()
        return [dict(r) for r in rows]

    def list_threads(self, limit: int = 50) -> list[dict]:
        with self.connect() as con:
            rows = con.execute("""
                SELECT m.thread_id,
                       COALESCE((SELECT substr(content,1,90) FROM messages x WHERE x.thread_id=m.thread_id AND x.role='user' ORDER BY x.id ASC LIMIT 1), 'محادثة جديدة') AS title,
                       MAX(m.created_at) AS updated_at,
                       COUNT(*) AS message_count
                FROM messages m GROUP BY m.thread_id ORDER BY MAX(m.id) DESC LIMIT ?
            """, (limit,)).fetchall()
        return [dict(r) for r in rows]

    def list_documents(self) -> list[dict]:
        with self.connect() as con:
            rows = con.execute("SELECT path,title,file_size,indexed_at FROM documents ORDER BY indexed_at DESC").fetchall()
        return [dict(r) for r in rows]
