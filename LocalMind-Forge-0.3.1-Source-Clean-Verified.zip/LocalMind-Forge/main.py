from __future__ import annotations
import os
import sys
import uuid
import queue
import threading
import subprocess
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText

from core.config import load_config, save_config, DB_PATH, CONFIG_PATH, WORKSPACE_DIR
from core.backup import create_backup, import_knowledge_pack
from core.database import LocalDatabase
from core.files import index_file, TEXT_EXTS
from core.knowledge_agent import KnowledgeAgent

APP_NAME = "LocalMind | العقل المحلي"

class LocalMindApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("1220x800")
        self.root.minsize(900, 620)
        self.root.configure(bg="#111827")
        self.config = load_config()
        self.db = LocalDatabase(DB_PATH)
        self.current_thread = "main"
        self.busy = False
        self.events: queue.Queue = queue.Queue()
        self._configure_styles()
        self._build_ui()
        self._load_thread_list()
        self._render_thread(self.current_thread)
        self._poll_events()
        self._set_model_status()

    def _configure_styles(self):
        style = ttk.Style()
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure("TFrame", background="#111827")
        style.configure("Panel.TFrame", background="#182235")
        style.configure("TLabel", background="#111827", foreground="#e5e7eb", font=("Segoe UI", 10))
        style.configure("Muted.TLabel", background="#182235", foreground="#9ca3af", font=("Segoe UI", 9))
        style.configure("Title.TLabel", background="#182235", foreground="#f9fafb", font=("Segoe UI", 15, "bold"))
        style.configure("TButton", font=("Segoe UI", 10), padding=(10, 7))
        style.configure("Accent.TButton", background="#2563eb", foreground="#ffffff", padding=(12, 8))
        style.map("Accent.TButton", background=[("active", "#1d4ed8"), ("disabled", "#374151")])
        style.configure("TEntry", fieldbackground="#0f172a", foreground="#f9fafb", insertcolor="#f9fafb")
        style.configure("TCheckbutton", background="#182235", foreground="#e5e7eb")
        style.configure("TScrollbar", background="#263449", troughcolor="#0f172a")

    def _build_ui(self):
        outer = ttk.Frame(self.root)
        outer.pack(fill="both", expand=True, padx=10, pady=10)
        self.sidebar = ttk.Frame(outer, style="Panel.TFrame", width=260)
        self.sidebar.pack(side="left", fill="y", padx=(0, 10))
        self.sidebar.pack_propagate(False)
        ttk.Label(self.sidebar, text="LocalMind", style="Title.TLabel").pack(anchor="w", padx=15, pady=(16, 0))
        ttk.Label(self.sidebar, text="قاعدة معرفة محلية تتعلم من ملفاتك", style="Muted.TLabel").pack(anchor="w", padx=15, pady=(3, 10))
        self.model_status = ttk.Label(self.sidebar, text="حالة المحرك: يفحص…", style="Muted.TLabel", wraplength=225)
        self.model_status.pack(anchor="w", padx=15, pady=(0, 12))
        ttk.Button(self.sidebar, text="＋ محادثة جديدة", command=self.new_chat).pack(fill="x", padx=12, pady=3)
        ttk.Button(self.sidebar, text="＋ إضافة / فهرسة ملفات", command=self.attach_files).pack(fill="x", padx=12, pady=3)
        ttk.Button(self.sidebar, text="▣ استيراد مجلد كامل", command=self.attach_folder).pack(fill="x", padx=12, pady=3)
        ttk.Button(self.sidebar, text="⚙ إعدادات النظام والويب", command=self.open_settings).pack(fill="x", padx=12, pady=3)
        ttk.Button(self.sidebar, text="▣ فتح مساحة العمل", command=self.open_workspace).pack(fill="x", padx=12, pady=3)
        ttk.Button(self.sidebar, text="◉ الذكريات والملفات المفهرسة", command=self.open_memory_window).pack(fill="x", padx=12, pady=3)
        ttk.Button(self.sidebar, text="نسخ المحادثة", command=self.copy_conversation).pack(fill="x", padx=12, pady=3)
        ttk.Button(self.sidebar, text="تصدير نسخة احتياطية ZIP", command=self.export_backup).pack(fill="x", padx=12, pady=3)
        ttk.Button(self.sidebar, text="استيراد حزمة معرفة ZIP", command=self.import_backup).pack(fill="x", padx=12, pady=3)
        ttk.Label(self.sidebar, text="المحادثات السابقة", style="Muted.TLabel").pack(anchor="w", padx=15, pady=(20, 5))
        history_box = ttk.Frame(self.sidebar, style="Panel.TFrame")
        history_box.pack(fill="both", expand=True, padx=10, pady=(0, 12))
        self.thread_list = tk.Listbox(history_box, bg="#0f172a", fg="#e5e7eb", selectbackground="#1d4ed8",
                                      selectforeground="#ffffff", relief="flat", borderwidth=0,
                                      font=("Segoe UI", 9), activestyle="none", exportselection=False)
        self.thread_list.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(history_box, orient="vertical", command=self.thread_list.yview)
        sb.pack(side="right", fill="y")
        self.thread_list.configure(yscrollcommand=sb.set)
        self.thread_list.bind("<<ListboxSelect>>", self._on_thread_selected)
        ttk.Label(self.sidebar, text="تُحفَظ المحادثات والذاكرة محليًا", style="Muted.TLabel", wraplength=220).pack(anchor="w", padx=15, pady=(0, 12))

        content = ttk.Frame(outer)
        content.pack(side="left", fill="both", expand=True)
        top = ttk.Frame(content, style="Panel.TFrame")
        top.pack(fill="x", pady=(0, 8))
        title_area = ttk.Frame(top, style="Panel.TFrame")
        title_area.pack(side="left", fill="x", expand=True, padx=15, pady=11)
        ttk.Label(title_area, text="المساعد الشخصي", style="Title.TLabel").pack(anchor="w")
        ttk.Label(title_area, text="محلي بالكامل • بلا نموذج أو API ذكاء اصطناعي • الويب اختياري", style="Muted.TLabel").pack(anchor="w", pady=(3, 0))
        self.status_var = tk.StringVar(value="جاهز")
        ttk.Label(top, textvariable=self.status_var, style="Muted.TLabel").pack(side="right", padx=15)

        chat_panel = ttk.Frame(content, style="Panel.TFrame")
        chat_panel.pack(fill="both", expand=True, pady=(0, 8))
        self.chat = ScrolledText(chat_panel, wrap="word", state="disabled", bg="#0b1220", fg="#e5e7eb",
                                 insertbackground="#ffffff", relief="flat", borderwidth=0,
                                 font=("Segoe UI", 11), padx=18, pady=15, spacing1=3, spacing3=5)
        self.chat.pack(fill="both", expand=True, padx=2, pady=2)
        self.chat.tag_configure("user_head", foreground="#93c5fd", font=("Segoe UI", 10, "bold"), justify="right", spacing1=12)
        self.chat.tag_configure("assistant_head", foreground="#6ee7b7", font=("Segoe UI", 10, "bold"), spacing1=12)
        self.chat.tag_configure("body", foreground="#e5e7eb", lmargin1=8, lmargin2=8, rmargin=8)
        self.chat.tag_configure("system", foreground="#fbbf24", font=("Segoe UI", 9, "italic"), spacing1=7, spacing3=7)

        composer = ttk.Frame(content, style="Panel.TFrame")
        composer.pack(fill="x")
        self.input = tk.Text(composer, height=4, wrap="word", bg="#0f172a", fg="#f9fafb", insertbackground="#ffffff",
                             relief="flat", font=("Segoe UI", 11), padx=12, pady=10, undo=True)
        self.input.pack(side="left", fill="both", expand=True, padx=(8, 4), pady=8)
        self.input.bind("<Control-Return>", self._send_hotkey)
        right_buttons = ttk.Frame(composer, style="Panel.TFrame")
        right_buttons.pack(side="right", fill="y", padx=(4, 8), pady=8)
        self.send_btn = ttk.Button(right_buttons, text="إرسال  ➤", style="Accent.TButton", command=self.send_message)
        self.send_btn.pack(fill="x", pady=(0, 5))
        ttk.Button(right_buttons, text="إرفاق ملف", command=self.attach_files).pack(fill="x", pady=2)
        ttk.Label(content, text="يرتب ويسترجع المعلومات من ملفاتك وذكرياتك دون نموذج ذكاء اصطناعي. فعّل الإنترنت للبحث العام عند الحاجة.", style="Muted.TLabel").pack(anchor="w", pady=(6, 0))

    def _append_chat(self, role: str, text: str):
        self.chat.configure(state="normal")
        if role == "user":
            self.chat.insert("end", "أنت\n", "user_head")
            self.chat.insert("end", text.strip() + "\n\n", "body")
        elif role == "assistant":
            self.chat.insert("end", "LocalMind\n", "assistant_head")
            self.chat.insert("end", text.strip() + "\n\n", "body")
        else:
            self.chat.insert("end", text.strip() + "\n\n", "system")
        self.chat.see("end")
        self.chat.configure(state="disabled")

    def _render_thread(self, thread_id: str):
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.configure(state="disabled")
        messages = self.db.get_messages(thread_id)
        if not messages:
            welcome = ("أهلًا بك في LocalMind.\n\n"
                       "اكتب سؤالك، أو أرفق ملفات ليقرأها ويفهرسها، أو اطلب منه البحث على الويب. "
                       "الذكريات الدائمة محفوظة داخل مجلد data.\n\n"
                       "يسترجع البرنامج معلومات من ملفاتك وذكرياتك دون نموذج ذكاء اصطناعي أو API. أضف أول ملف من الزر الجانبي.\n\nاكتب /help لعرض الأوامر.")
            self._append_chat("system", welcome)
        else:
            for item in messages:
                self._append_chat(item["role"], item["content"])

    def _load_thread_list(self):
        self.threads = self.db.list_threads()
        self.thread_list.delete(0, "end")
        self.thread_ids = []
        for item in self.threads:
            title = (item["title"] or "محادثة")
            title = title.replace("\n", " ")
            if len(title) > 34: title = title[:34] + "…"
            self.thread_list.insert("end", title)
            self.thread_ids.append(item["thread_id"])
        if self.current_thread in self.thread_ids:
            idx = self.thread_ids.index(self.current_thread)
            self.thread_list.selection_clear(0, "end")
            self.thread_list.selection_set(idx)

    def _on_thread_selected(self, _event=None):
        sel = self.thread_list.curselection()
        if not sel: return
        if self.busy:
            self.status_var.set("انتظر انتهاء الرد الحالي قبل تبديل المحادثة")
            return
        self.current_thread = self.thread_ids[sel[0]]
        self._render_thread(self.current_thread)

    def new_chat(self):
        if self.busy:
            messagebox.showinfo("انتظر", "انتظر انتهاء الرد الحالي أولًا.")
            return
        self.current_thread = uuid.uuid4().hex[:12]
        self.thread_list.selection_clear(0, "end")
        self._render_thread(self.current_thread)
        self.status_var.set("محادثة جديدة")

    def _send_hotkey(self, _event=None):
        self.send_message()
        return "break"

    def send_message(self):
        if self.busy: return
        text = self.input.get("1.0", "end-1c").strip()
        if not text: return
        self.input.delete("1.0", "end")
        if text.startswith("/remember "):
            value = text[len("/remember "):].strip()
            if ":" in value:
                key, content = value.split(":", 1)
            else:
                key, content = "معلومة", value
            self.db.remember(key.strip(), content.strip())
            self._append_chat("user", text)
            answer = f"حُفظت في الذاكرة المحلية تحت عنوان «{key.strip()}»."
            self.db.add_message("user", text, self.current_thread)
            self.db.add_message("assistant", answer, self.current_thread)
            self._append_chat("assistant", answer)
            self._load_thread_list()
            return
        self.db.add_message("user", text, self.current_thread)
        self._append_chat("user", text)
        self.busy = True
        self.send_btn.configure(state="disabled")
        self.status_var.set("يبحث في المعرفة المحلية…")
        self.events.put(("status", "يبحث في ملفاتك وذكرياتك المحلية…"))
        thread_id = self.current_thread
        worker = threading.Thread(target=self._answer_worker, args=(text, thread_id), daemon=True)
        worker.start()

    def _answer_worker(self, prompt: str, thread_id: str):
        try:
            agent = KnowledgeAgent(self.db, self.config,
                                   status_callback=lambda msg: self.events.put(("status", msg)))
            answer = agent.answer(prompt)
            self.events.put(("answer", thread_id, answer))
        except Exception as e:
            self.events.put(("error", thread_id, f"{type(e).__name__}: {e}"))

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "status":
                    self.status_var.set(event[1])
                elif kind in {"answer", "error"}:
                    _, thread_id, content = event
                    if kind == "answer":
                        self.db.add_message("assistant", content, thread_id)
                        if self.current_thread == thread_id: self._append_chat("assistant", content)
                    else:
                        error_text = "حدث خطأ أثناء تشغيل المساعد:\n" + content
                        if self.current_thread == thread_id: self._append_chat("system", error_text)
                        self.db.add_message("assistant", error_text, thread_id)
                    self.busy = False
                    self.send_btn.configure(state="normal")
                    self.status_var.set("جاهز")
                    self._load_thread_list()
                    self._set_model_status()
                elif kind == "index_done":
                    _, summary = event
                    self._append_chat("system", summary)
                    self.status_var.set("اكتملت فهرسة الملفات")
                    self._refresh_memory_status()
                    self._set_model_status()
                elif kind == "index_error":
                    self._append_chat("system", "تعذّرت فهرسة ملف: " + event[1])
                    self.status_var.set("انتهت فهرسة الملفات مع أخطاء")
                elif kind == "backup_done":
                    self._append_chat("system", event[1])
                    self.status_var.set("اكتملت عملية النسخ الاحتياطي")
                    self._set_model_status()
                elif kind == "pack_import_done":
                    self._append_chat("system", event[1])
                    self.status_var.set("اكتمل استيراد حزمة المعرفة")
                    self._set_model_status()
                    self._refresh_memory_status()
                elif kind == "tool_note":
                    self._append_chat("system", event[1])
        except queue.Empty:
            pass
        self.root.after(120, self._poll_events)

    def attach_files(self):
        paths = filedialog.askopenfilenames(title="اختر ملفات لفهرستها في قاعدة المعرفة المحلية")
        if not paths: return
        self.status_var.set(f"فهرسة {len(paths)} ملف…")
        def worker():
            ok, errors = [], []
            for path in paths:
                try:
                    chars, chunks = index_file(self.db, path)
                    ok.append(f"{Path(path).name}: {chars:,} حرف، {chunks} مقطع")
                except Exception as e:
                    errors.append(f"{Path(path).name}: {e}")
            summary = "اكتملت فهرسة الملفات.\n" + ("\n".join(ok) if ok else "لم تتم فهرسة أي ملف.")
            if errors: summary += "\n\nأخطاء:\n" + "\n".join(errors)
            self.events.put(("index_done", summary))
        threading.Thread(target=worker, daemon=True).start()

    def attach_folder(self):
        folder = filedialog.askdirectory(title="اختر مجلدًا لفهرسة ملفاته المدعومة")
        if not folder:
            return
        root_path = Path(folder)
        allowed = set(TEXT_EXTS) | {".pdf", ".docx", ".xlsx", ".pptx", ".epub"}
        paths = []
        for base, dirs, files in os.walk(root_path):
            # Keep version-control and cache folders out of an accidental large scan.
            dirs[:] = [d for d in dirs if d not in {".git", "node_modules", "__pycache__", ".venv", "venv"}]
            for name in files:
                p = Path(base) / name
                if p.suffix.lower() in allowed or (not p.suffix and name.startswith(".")):
                    paths.append(str(p))
        if not paths:
            messagebox.showinfo("لا توجد ملفات مدعومة", "لم أعثر على ملفات من الأنواع المدعومة داخل هذا المجلد.")
            return
        if len(paths) > 5000:
            if not messagebox.askyesno("مجلد كبير", f"عُثر على {len(paths):,} ملفًا. هل تريد متابعة فهرستها؟"):
                return
        self.status_var.set(f"فهرسة {len(paths):,} ملف من المجلد…")
        def worker():
            ok, errors = [], []
            for idx, path in enumerate(paths, 1):
                try:
                    chars, chunks = index_file(self.db, path)
                    ok.append(f"{Path(path).name}: {chars:,} حرف، {chunks} مقطع")
                except Exception as e:
                    errors.append(f"{Path(path).name}: {e}")
                if idx % 25 == 0:
                    self.events.put(("status", f"تمت معالجة {idx:,} / {len(paths):,} ملفًا…"))
            summary = f"اكتملت فهرسة المجلد. النجاح: {len(ok):,} | الأخطاء/التخطي: {len(errors):,}."
            if ok:
                summary += "\n\nأول الملفات المفهرسة:\n" + "\n".join(ok[:80])
            if errors:
                summary += "\n\nأول الأخطاء:\n" + "\n".join(errors[:40])
            self.events.put(("index_done", summary))
        threading.Thread(target=worker, daemon=True).start()

    def open_settings(self):
        win = tk.Toplevel(self.root)
        win.title("إعدادات LocalMind")
        win.configure(bg="#182235")
        win.geometry("680x360")
        win.transient(self.root)
        frame = ttk.Frame(win, style="Panel.TFrame", padding=18)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="إعدادات المعرفة المحلية", style="Title.TLabel").pack(anchor="w", pady=(0, 12))
        web_var = tk.BooleanVar(value=bool(self.config.get("web_search_enabled", True)))
        workspace_var = tk.StringVar(value=str(self.config.get("workspace_path", WORKSPACE_DIR)))
        ttk.Checkbutton(frame, text="السماح بالبحث العام على الإنترنت عند الطلب أو غياب مصدر محلي كافٍ", variable=web_var).pack(anchor="w", pady=8)
        ttk.Label(frame, text="لا يُستخدم أي نموذج ذكاء اصطناعي أو API. عند استخدام بحث الويب، يُرسل نص الاستعلام إلى محرك البحث فقط.", style="Muted.TLabel", wraplength=600).pack(anchor="w", pady=8)
        ttk.Label(frame, text="مجلد مساحة العمل لإنشاء الملفات:", style="Muted.TLabel").pack(anchor="w", pady=(10, 3))
        row = ttk.Frame(frame, style="Panel.TFrame")
        row.pack(fill="x")
        ttk.Entry(row, textvariable=workspace_var).pack(side="left", fill="x", expand=True)
        def pick_workspace():
            p = filedialog.askdirectory(title="اختيار مساحة العمل")
            if p: workspace_var.set(p)
        ttk.Button(row, text="اختيار…", command=pick_workspace).pack(side="left", padx=(8, 0))
        def save():
            workspace = Path(workspace_var.get()).expanduser()
            if not workspace.is_absolute():
                messagebox.showerror("قيمة غير صالحة", "يجب أن يكون مسار مساحة العمل كاملًا.", parent=win)
                return
            try:
                workspace.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                messagebox.showerror("تعذّر إنشاء المسار", str(exc), parent=win)
                return
            self.config.update({"web_search_enabled": web_var.get(), "workspace_path": str(workspace.resolve())})
            save_config(self.config)
            self._set_model_status()
            win.destroy()
            self.status_var.set("تم حفظ الإعدادات")
        btns = ttk.Frame(frame, style="Panel.TFrame")
        btns.pack(fill="x", pady=(20, 0))
        ttk.Button(btns, text="إغلاق", command=win.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="حفظ", style="Accent.TButton", command=save).pack(side="right", padx=4)

    def _set_model_status(self):
        docs = len(self.db.list_documents()) if hasattr(self, "db") else 0
        notes = len(self.db.list_notes(100000)) if hasattr(self, "db") else 0
        web = "مفعّل" if self.config.get("web_search_enabled", True) else "معطّل"
        self.model_status.configure(text=f"المحرك: استرجاع محلي بلا نموذج\nالملفات: {docs:,} | الذكريات: {notes:,}\nبحث الويب: {web}")

    def open_workspace(self):
        p = Path(self.config.get("workspace_path", WORKSPACE_DIR)).expanduser()
        p.mkdir(parents=True, exist_ok=True)
        try:
            if sys.platform.startswith("win"): os.startfile(str(p))
            elif sys.platform == "darwin": subprocess.Popen(["open", str(p)])
            else: subprocess.Popen(["xdg-open", str(p)])
        except Exception as e: messagebox.showerror("تعذّر الفتح", str(e))

    def copy_conversation(self):
        content = self.chat.get("1.0", "end-1c")
        self.root.clipboard_clear()
        self.root.clipboard_append(content)
        self.status_var.set("تم نسخ نص المحادثة")

    def export_backup(self):
        destination = filedialog.asksaveasfilename(
            title="حفظ نسخة احتياطية من LocalMind",
            defaultextension=".zip",
            filetypes=[("LocalMind backup ZIP", "*.zip")],
            initialfile="LocalMind-Backup.zip",
        )
        if not destination:
            return
        self.status_var.set("يُنشئ نسخة احتياطية متسقة من قاعدة البيانات…")
        def worker():
            try:
                path = create_backup(destination, DB_PATH, CONFIG_PATH)
                self.events.put(("backup_done", f"اكتملت النسخة الاحتياطية: {path}\nتتضمن قاعدة البيانات والمحادثات والذكريات والنص المفهرس والإعدادات."))
            except Exception as exc:
                self.events.put(("backup_done", f"تعذّر إنشاء النسخة الاحتياطية: {type(exc).__name__}: {exc}"))
        threading.Thread(target=worker, daemon=True).start()

    def import_backup(self):
        source = filedialog.askopenfilename(
            title="اختر نسخة LocalMind ZIP لاستيراد المعرفة",
            filetypes=[("LocalMind knowledge pack", "*.zip"), ("All files", "*.*")],
        )
        if not source:
            return
        if not messagebox.askyesno("استيراد معرفة", "سيتم استيراد الذكريات والمقاطع النصية من حزمة المعرفة. لن تُستبدل قاعدة البيانات الحالية كاملة. متابعة؟"):
            return
        self.status_var.set("يستورد المعرفة من الملف المضغوط…")
        def worker():
            try:
                stats = import_knowledge_pack(source, self.db)
                message = (f"اكتمل الاستيراد. الذكريات الجديدة: {stats['notes']:,}؛ "
                           f"الملفات: {stats['documents']:,}؛ المقاطع النصية: {stats['chunks']:,}.\n"
                           "المصادر المستوردة تحمل بادئة localmind-pack://؛ أعد استيراد الملفات الأصلية عند الحاجة إلى مساراتها الأصلية.")
                self.events.put(("pack_import_done", message))
            except Exception as exc:
                self.events.put(("pack_import_done", f"تعذّر الاستيراد: {type(exc).__name__}: {exc}"))
        threading.Thread(target=worker, daemon=True).start()

    def open_memory_window(self):
        win = tk.Toplevel(self.root)
        win.title("الذاكرة المحلية وقاعدة المعرفة")
        win.configure(bg="#182235")
        win.geometry("860x560")
        wrap = ttk.Frame(win, style="Panel.TFrame", padding=15)
        wrap.pack(fill="both", expand=True)
        ttk.Label(wrap, text="الذكريات الصريحة", style="Title.TLabel").pack(anchor="w")
        ttk.Label(wrap, text="تُحفظ في قاعدة SQLite المحلية. احذف ما لا تريد بقاءه.", style="Muted.TLabel").pack(anchor="w", pady=(3, 8))
        notes_list = tk.Listbox(wrap, bg="#0f172a", fg="#e5e7eb", selectbackground="#1d4ed8", relief="flat", font=("Segoe UI", 10), height=9)
        notes_list.pack(fill="x", pady=(0, 8))
        notes_data = []
        def refresh_notes():
            nonlocal notes_data
            notes_data = self.db.list_notes(200)
            notes_list.delete(0, "end")
            for n in notes_data:
                notes_list.insert("end", f"#{n['id']}  {n['key']}: {n['value'][:160]}")
        def delete_note():
            sel = notes_list.curselection()
            if not sel: return
            n = notes_data[sel[0]]
            if messagebox.askyesno("حذف الذاكرة", f"حذف الذاكرة رقم {n['id']}؟", parent=win):
                self.db.forget_note(n['id']); refresh_notes()
        bar = ttk.Frame(wrap, style="Panel.TFrame"); bar.pack(fill="x")
        ttk.Button(bar, text="حذف الذاكرة المحددة", command=delete_note).pack(side="right")
        ttk.Button(bar, text="تحديث", command=refresh_notes).pack(side="right", padx=5)
        ttk.Separator(wrap).pack(fill="x", pady=12)
        ttk.Label(wrap, text="الملفات المفهرسة", style="Title.TLabel").pack(anchor="w")
        docs_text = ScrolledText(wrap, height=10, bg="#0f172a", fg="#e5e7eb", relief="flat", font=("Consolas", 9), wrap="word")
        docs_text.pack(fill="both", expand=True, pady=(7, 0))
        docs_text.insert("end", "\n\n".join(f"{d['title']}\n{d['path']}\nحجم: {d['file_size']} bytes | فُهرس: {d['indexed_at']}" for d in self.db.list_documents()) or "لا توجد ملفات مفهرسة.")
        docs_text.configure(state="disabled")
        refresh_notes()

    def _refresh_memory_status(self):
        self.status_var.set(f"الذاكرة: {len(self.db.list_notes(1000))} مذكرة صريحة؛ {len(self.db.list_documents())} ملفًا مفهرسًا")


def main():
    root = tk.Tk()
    LocalMindApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
