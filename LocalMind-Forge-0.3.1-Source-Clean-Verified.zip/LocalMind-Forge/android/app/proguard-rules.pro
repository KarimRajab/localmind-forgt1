# No custom rules required for this model-free, dependency-light application.
