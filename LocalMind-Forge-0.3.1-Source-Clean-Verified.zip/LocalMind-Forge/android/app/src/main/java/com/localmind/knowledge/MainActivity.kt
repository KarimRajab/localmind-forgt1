package com.localmind.knowledge

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.text.method.LinkMovementMethod
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.database.Cursor
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private lateinit var db: LocalDatabase
    private lateinit var messagesBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private var webEnabled = true
    private var busy = false
    private val maxFileBytes = 40 * 1024 * 1024
    private val supportedTextExts = setOf(
        "txt", "md", "rst", "csv", "tsv", "json", "jsonl", "xml", "html", "htm", "log", "yaml", "yml", "toml", "ini", "cfg", "conf", "properties", "sql", "js", "ts", "jsx", "tsx", "css", "scss", "c", "h", "cpp", "hpp", "cs", "java", "go", "rs", "sh", "bat", "ps1", "php", "rb", "kt", "swift", "r", "lua", "env", "py", "kt", "swift", "xml"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LocalDatabase(this)
        webEnabled = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("web_enabled", true)
        buildUi()
        renderHistory()
    }

    override fun onDestroy() {
        executor.shutdown()
        db.close()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(12, 18, 31))
            setPadding(dp(12), dp(8), dp(12), dp(10))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(24, 34, 53))
            setPadding(dp(15), dp(12), dp(15), dp(12))
        }
        header.addView(TextView(this).apply {
            text = "LocalMind"
            textSize = 24f
            setTextColor(Color.rgb(246, 248, 252))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        header.addView(TextView(this).apply {
            text = "ذاكرة محلية • بحث في ملفاتك • بلا نموذج أو API ذكاء اصطناعي"
            textSize = 12f
            setTextColor(Color.rgb(173, 190, 212))
            setPadding(0, dp(4), 0, 0)
        })
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tools.addView(toolButton("إرفاق ملفات") { pickFiles() }, weightedButtonParams())
        tools.addView(toolButton("استيراد مجلد") { pickFolder() }, weightedButtonParams())
        root.addView(tools, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })

        val tools2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tools2.addView(toolButton("الملفات") { showDocuments() }, weightedButtonParams())
        tools2.addView(toolButton("الذكريات") { showNotes() }, weightedButtonParams())
        tools2.addView(toolButton(if (webEnabled) "الويب: يعمل" else "الويب: متوقف") { toggleWeb(it as Button) }, weightedButtonParams())
        root.addView(tools2, LinearLayout.LayoutParams(-1, -2))
        root.addView(toolButton("تصدير نسخة احتياطية ZIP") { createBackup() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        root.addView(toolButton("استيراد حزمة معرفة ZIP (Android / Windows)") { pickKnowledgePack() }, LinearLayout.LayoutParams(-1, -2))

        scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.rgb(18, 27, 43))
        }
        messagesBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(12))
        }
        scroll.addView(messagesBox, ScrollView.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8); bottomMargin = dp(8) })

        val composer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        input = EditText(this).apply {
            hint = "اكتب سؤالًا أو /remember عنوان: معلومة"
            textSize = 15f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(146, 160, 183))
            setBackgroundColor(Color.rgb(24, 34, 53))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            minLines = 2
            maxLines = 5
            gravity = Gravity.TOP or Gravity.START
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
            }
        }
        composer.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        sendButton = Button(this).apply {
            text = "إرسال"
            setOnClickListener { sendMessage() }
        }
        composer.addView(sendButton, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(7) })
        root.addView(composer, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun weightedButtonParams() = LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(3); leftMargin = dp(3) }
    private fun toolButton(label: String, callback: (Button) -> Unit) = Button(this).apply {
        text = label
        textSize = 11f
        minHeight = dp(42)
        setPadding(dp(2), 0, dp(2), 0)
        setOnClickListener { callback(this) }
    }

    private fun renderHistory() {
        messagesBox.removeAllViews()
        val history = db.recentMessages(100)
        if (history.isEmpty()) {
            addBubble("LocalMind جاهز. أرفق ملفات أو استورد مجلدًا ثم اسأل عما يحتويه. لا يستخدم التطبيق نموذجًا لغويًا أو API ذكاء اصطناعي؛ يستخرج المقاطع المطابقة ويرتبها. اكتب /help لعرض الأوامر.", false)
        } else history.forEach { (role, text) -> addBubble(text, role == "user") }
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun addBubble(text: String, isUser: Boolean) {
        val view = TextView(this).apply {
            this.text = (if (isUser) "أنت\n" else "LocalMind\n") + text
            textSize = 14f
            setTextColor(if (isUser) Color.rgb(231, 241, 255) else Color.rgb(225, 233, 244))
            setBackgroundColor(if (isUser) Color.rgb(33, 63, 105) else Color.rgb(30, 43, 63))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setLineSpacing(dp(2).toFloat(), 1f)
            if (!isUser) {
                autoLinkMask = android.text.util.Linkify.WEB_URLS
                movementMethod = LinkMovementMethod.getInstance()
            }
        }
        messagesBox.addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun sendMessage() {
        if (busy) return
        val prompt = input.text.toString().trim()
        if (prompt.isBlank()) return
        input.setText("")
        db.addMessage("user", prompt)
        addBubble(prompt, true)
        busy = true
        sendButton.isEnabled = false
        executor.execute {
            val response = try { answer(prompt) } catch (e: Exception) { "تعذّر تنفيذ الطلب محليًا: ${e.javaClass.simpleName}: ${e.message ?: ""}" }
            db.addMessage("assistant", response)
            runOnUiThread {
                addBubble(response, false)
                busy = false
                sendButton.isEnabled = true
                scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
            }
        }
    }

    private fun answer(raw: String): String {
        val normalized = LocalDatabase.normalize(raw)
        if (normalized in setOf("مرحبا", "اهلا", "اهلا بك", "السلام عليكم", "صباح الخير", "مساء الخير", "شكرا", "شكرًا")) {
            return "أهلًا بك في LocalMind. أستطيع استرجاع المعلومات من ملفاتك وذكرياتك، وحفظ ما تعلّمني إياه باستخدام /remember. اكتب /help لمعرفة الأوامر."
        }
        if (normalized == "/help" || normalized == "مساعدة" || normalized == "المساعدة") return helpText()
        if (normalized == "/status" || normalized == "حالة النظام") {
            val counts = db.counts()
            return "حالة LocalMind\nالمحرك: استرجاع محلي حتمي بلا نموذج أو API\nالملفات المفهرسة: ${counts.first}\nالذكريات: ${counts.second}\nبحث الويب: ${if (webEnabled) "مفعّل" else "متوقف"}"
        }
        if (normalized.startsWith("/remember ") || normalized.startsWith("تذكر ان ") || normalized.startsWith("احفظ في ذاكرتك ")) {
            var rest = raw.substringAfter(' ').trim()
            if (normalized.startsWith("احفظ في ذاكرتك ")) rest = raw.substringAfter("احفظ في ذاكرتك ", "").trim()
            if (normalized.startsWith("تذكر ان ")) rest = raw.substringAfter("تذكر أن ", raw.substringAfter("تذكر ان ", "")).trim()
            val title = rest.substringBefore(":", "معلومة من المستخدم").trim().ifBlank { "معلومة من المستخدم" }
            val content = if (rest.contains(":")) rest.substringAfter(":").trim() else rest
            if (content.isBlank()) return "الصيغة: /remember العنوان: المعلومة"
            val id = db.remember(title, content)
            return "حفظت المعلومة محليًا. رقمها: $id. أستطيع استرجاعها لاحقًا من قاعدة البيانات المحلية."
        }
        if (normalized.startsWith("/forget ")) {
            val id = raw.substringAfter(' ', "").trim().toLongOrNull() ?: return "الصيغة: /forget رقم_الذاكرة"
            return if (db.forgetNote(id)) "حُذفت الذاكرة رقم $id." else "لا توجد ذاكرة بهذا الرقم."
        }
        if (normalized == "/notes" || normalized == "الذكريات" || normalized == "ماذا تتذكر") {
            val notes = db.notes()
            return if (notes.isEmpty()) "لا توجد ذكريات محفوظة. استخدم /remember العنوان: المعلومة" else notes.joinToString("\n\n") { "#${it.id} — ${it.title}: ${it.content}" }
        }
        if (normalized == "/files" || normalized == "الملفات المفهرسة" || normalized == "ملفاتي") {
            val docs = db.documentList()
            return if (docs.isEmpty()) "لا توجد ملفات مفهرسة بعد. اضغط إرفاق ملفات أو استيراد مجلد." else docs.joinToString("\n\n")
        }
        if (normalized.startsWith("/web ")) return webSearch(raw.substringAfter(' ', ""))
        val forceLocalSearch = normalized.startsWith("/search ")
        val q = if (forceLocalSearch) raw.substringAfter(' ', "") else raw

        val qTokens = LocalDatabase.tokens(q)
        val noteHits = db.notes().mapNotNull { note ->
            val text = LocalDatabase.normalize(note.title + " " + note.content)
            val match = qTokens.count { text.contains(it) }
            if (match > 0) (match.toDouble() / maxOf(1, qTokens.size)) to note else null
        }.sortedByDescending { it.first }.take(4)
        val docs = db.search(q, 5)
        if (docs.isNotEmpty()) {
            val out = StringBuilder("مقاطع مطابقة من قاعدة المعرفة المحلية — مرتبة بالكلمات المتطابقة:\n")
            docs.forEachIndexed { i, hit ->
                out.append("\n${i + 1}. ${hit.title} — المقطع ${hit.chunkNo + 1}\nالمصدر: ${hit.uri}\n> ")
                out.append(hit.content.take(1200).replace("\n", "\n> "))
                out.append("\n")
            }
            if (noteHits.isNotEmpty()) out.append("\nذكريات قريبة:\n").append(noteHits.joinToString("\n") { "- ${it.second.title}: ${it.second.content.take(500)}" })
            out.append("\nالمحتوى مقتطف من المصادر الأصلية وليس نصًا مولّدًا أو استنتاجًا. تحقق من السياق داخل الملف عند الحاجة.")
            return out.toString()
        }
        if (noteHits.isNotEmpty()) {
            return "وجدت هذه الذكريات ذات الصلة:\n" + noteHits.joinToString("\n\n") { "- ${it.second.title}: ${it.second.content}" } + "\n\nلم أعثر على مقطع مطابق في الملفات المفهرسة."
        }
        if (forceLocalSearch) return "لم أعثر على مادة مطابقة في الملفات المحلية. جرب كلمات أخرى أو استورد ملفًا جديدًا."
        if (webEnabled) return "لم أعثر على مادة مطابقة في ملفاتك وذكرياتك المحلية.\n\n" + webSearch(raw)
        return "لم أعثر على مادة كافية في قاعدة المعرفة المحلية. أضف ملفًا أو احفظ معلومة باستخدام /remember. البحث عبر الإنترنت متوقف حاليًا."
    }

    private fun helpText() = """LocalMind: مساعد معرفة محلي بلا نموذج أو API ذكاء اصطناعي.
• أرفق ملفات نصية/مستندات أو استورد مجلدًا لفهرسة محتواه.
• /search كلمات — بحث في الملفات.
• /web كلمات — بحث ويب يدوي.
• /remember العنوان: المعلومة — احفظ معلومة في ذاكرتك المحلية.
• /notes — عرض الذكريات.
• /forget رقم — حذف ذاكرة.
• /files — عرض ملفات قاعدة المعرفة.
• /status — حالة النظام.

تُحفظ البيانات داخل مساحة التطبيق الخاصة. البحث المحلي لا يرسل ملفاتك إلى الإنترنت. عند البحث على الويب، يُرسل الاستعلام فقط إلى محرك البحث. لا يستخدم هذا الإصدار نموذجًا لغويًا، لذا فهو يسترجع ويقتبس ويرتب ولا يؤلف إجابات لغوية حرة."""

    private fun toggleWeb(button: Button) {
        webEnabled = !webEnabled
        getSharedPreferences("settings", MODE_PRIVATE).edit().putBoolean("web_enabled", webEnabled).apply()
        button.text = if (webEnabled) "الويب: يعمل" else "الويب: متوقف"
        Toast.makeText(this, if (webEnabled) "بحث الويب مفعّل" else "بحث الويب متوقف", Toast.LENGTH_SHORT).show()
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, REQ_FILES)
    }

    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        startActivityForResult(i, REQ_FOLDER)
    }

    @Deprecated("Activity Result API would need an additional AndroidX dependency; this app intentionally stays dependency-light.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == REQ_FILES) {
            val uris = mutableListOf<Uri>()
            data.data?.let { uris.add(it) }
            data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
            importUris(uris.distinct())
        } else if (requestCode == REQ_FOLDER) {
            val tree = data.data ?: return
            try { contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            executor.execute {
                val uris = mutableListOf<Uri>()
                collectTree(tree, DocumentsContract.getTreeDocumentId(tree), uris, 0)
                importUrisNow(uris)
            }
        } else if (requestCode == REQ_EXPORT) {
            data.data?.let { destination -> executor.execute { exportBackup(destination) } }
        } else if (requestCode == REQ_IMPORT_PACK) {
            data.data?.let { source -> executor.execute { importKnowledgePack(source) } }
        }
    }

    private fun collectTree(tree: Uri, documentId: String, uris: MutableList<Uri>, depth: Int) {
        if (depth > 24 || uris.size >= 5000) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, documentId)
        val projection = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE)
        try {
            contentResolver.query(children, projection, null, null, null)?.use { c ->
                while (c.moveToNext() && uris.size < 5000) {
                    val id = c.getString(0)
                    val name = c.getString(1) ?: ""
                    val mime = c.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) collectTree(tree, id, uris, depth + 1)
                    else if (isSupportedName(name)) uris.add(DocumentsContract.buildDocumentUriUsingTree(tree, id))
                }
            }
        } catch (_: Exception) {}
    }

    private fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        Toast.makeText(this, "بدأت فهرسة ${uris.size} ملفًا…", Toast.LENGTH_SHORT).show()
        executor.execute { importUrisNow(uris) }
    }

    private fun importUrisNow(uris: List<Uri>) {
        var ok = 0
        val errors = mutableListOf<String>()
        for ((index, uri) in uris.withIndex()) {
            if (index >= 5000) break
            try {
                val title = displayName(uri)
                if (!isSupportedName(title)) { errors.add("$title: صيغة غير مدعومة"); continue }
                val bytes = readBytesLimited(uri)
                val text = extractText(title, bytes)
                if (text.isBlank()) { errors.add("$title: لم يُستخرج نص"); continue }
                db.indexText(uri.toString(), title, text, bytes.size.toLong())
                ok++
            } catch (e: Exception) {
                errors.add("${safeName(uri)}: ${e.message ?: e.javaClass.simpleName}")
            }
        }
        val summary = "اكتملت الفهرسة: نجاح $ok من ${uris.size} ملفًا." + if (errors.isNotEmpty()) "\n\nتم تخطي/فشل أول الملفات:\n" + errors.take(30).joinToString("\n") else ""
        runOnUiThread {
            addBubble(summary, false)
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun isSupportedName(name: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return ext in supportedTextExts || ext in setOf("pdf", "docx", "xlsx", "pptx", "epub")
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: uri.lastPathSegment ?: "file"
        }
        return uri.lastPathSegment ?: "file"
    }
    private fun safeName(uri: Uri) = try { displayName(uri) } catch (_: Exception) { uri.lastPathSegment ?: "file" }

    private fun readBytesLimited(uri: Uri): ByteArray {
        contentResolver.openInputStream(uri).use { stream ->
            requireNotNull(stream) { "تعذّر فتح الملف" }
            val out = ByteArrayOutputStream()
            val buf = ByteArray(64 * 1024)
            var total = 0
            while (true) {
                val count = stream.read(buf)
                if (count < 0) break
                total += count
                if (total > maxFileBytes) throw IllegalArgumentException("الملف أكبر من حد الهاتف (40 MB)")
                out.write(buf, 0, count)
            }
            return out.toByteArray()
        }
    }

    private fun extractText(name: String, bytes: ByteArray): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "docx" -> zipTexts(bytes).filter { it.first == "word/document.xml" }.joinToString("\n") { xmlText(it.second) }
            "pptx" -> zipTexts(bytes).filter { it.first.matches(Regex("ppt/slides/slide\\d+\\.xml")) }.sortedBy { it.first.filter(Char::isDigit).toIntOrNull() ?: 0 }.joinToString("\n\n") { xmlText(it.second) }
            "xlsx" -> extractXlsx(bytes)
            "epub" -> zipTexts(bytes).filter { it.first.endsWith(".html") || it.first.endsWith(".xhtml") || it.first.endsWith(".htm") }.joinToString("\n\n") { htmlText(it.second) }
            "pdf" -> extractPdf(bytes)
            "html", "htm" -> htmlText(bytes.toString(StandardCharsets.UTF_8))
            "xml" -> xmlText(bytes.toString(StandardCharsets.UTF_8))
            else -> bytes.toString(StandardCharsets.UTF_8).replace("\u0000", "").trim()
        }
    }

    private fun zipTexts(bytes: ByteArray): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        var totalInflated = 0L
        val maxInflatedArchive = 100L * 1024L * 1024L
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val relevantText = !entry.isDirectory && entry.name.length < 1000 &&
                    (entry.name.endsWith(".xml", true) || entry.name.endsWith(".html", true) ||
                     entry.name.endsWith(".xhtml", true) || entry.name.endsWith(".htm", true))
                val data = if (relevantText && out.size < 1200) ByteArrayOutputStream() else null
                val buffer = ByteArray(16 * 1024)
                var entryBytes = 0L
                while (true) {
                    val n = zip.read(buffer)
                    if (n < 0) break
                    entryBytes += n
                    totalInflated += n
                    if (totalInflated > maxInflatedArchive) throw IllegalArgumentException("الحجم المفكوك من الملف المضغوط تجاوز 100 MB")
                    if (data != null && entryBytes > 8L * 1024L * 1024L) throw IllegalArgumentException("جزء XML داخل الملف المضغوط أكبر من حد 8 MB")
                    data?.write(buffer, 0, n)
                }
                if (data != null) out.add(entry.name to data.toString("UTF-8"))
                zip.closeEntry()
            }
        }
        return out
    }

    private fun extractXlsx(bytes: ByteArray): String {
        val parts = zipTexts(bytes)
        val sharedXml = parts.firstOrNull { it.first == "xl/sharedStrings.xml" }?.second ?: ""
        val shared = Regex("<si[^>]*>(.*?)</si>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(sharedXml)
            .map { xmlText(it.groupValues[1]) }.toList()
        val sheets = parts.filter { it.first.matches(Regex("xl/worksheets/sheet\\d+\\.xml")) }.sortedBy { it.first.filter(Char::isDigit).toIntOrNull() ?: 0 }
        return sheets.joinToString("\n\n") { (path, xml) ->
            val rows = Regex("<row[^>]*>(.*?)</row>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(xml).map { row ->
                Regex("<c([^>]*)>(.*?)</c>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(row.groupValues[1]).map { cell ->
                    val attrs = cell.groupValues[1]
                    val value = Regex("<v[^>]*>(.*?)</v>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(cell.groupValues[2])?.groupValues?.get(1) ?: ""
                    if (Regex("t=\"s\"").containsMatchIn(attrs)) shared.getOrNull(value.toIntOrNull() ?: -1) ?: value else htmlEntity(value)
                }.joinToString(" | ")
            }.toList()
            "[$path]\n" + rows.joinToString("\n")
        }
    }

    private fun extractPdf(bytes: ByteArray): String {
        com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(applicationContext)
        com.tom_roush.pdfbox.pdmodel.PDDocument.load(ByteArrayInputStream(bytes)).use { doc ->
            return com.tom_roush.pdfbox.text.PDFTextStripper().getText(doc)
        }
    }

    private fun htmlText(value: String): String = xmlText(value.replace(Regex("(?is)<(script|style|noscript)[^>]*>.*?</\\1>"), " ").replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</li>|</h[1-6]>"), "\n").replace(Regex("<[^>]+>"), " "))
    private fun xmlText(value: String): String = htmlEntity(value.replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim())
    private fun htmlEntity(value: String): String = value.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&#39;", "'").replace("&nbsp;", " ")

    private fun webSearch(query: String): String {
        if (!webEnabled) return "بحث الويب متوقف من الإعدادات."
        val q = query.trim()
        if (q.isBlank()) return "اكتب عبارة البحث بعد /web."
        var connection: HttpURLConnection? = null
        try {
            val encoded = URLEncoder.encode(q, "UTF-8")
            connection = (URL("https://html.duckduckgo.com/html/?q=$encoded").openConnection() as HttpURLConnection).apply {
                connectTimeout = 7000
                readTimeout = 8000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "LocalMind-Android/0.3.0 (offline-first knowledge assistant)")
                instanceFollowRedirects = true
            }
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                val collected = StringBuilder()
                val buffer = CharArray(8192)
                val maxChars = 2_000_000
                while (collected.length < maxChars) {
                    val n = reader.read(buffer, 0, minOf(buffer.size, maxChars - collected.length))
                    if (n < 0) break
                    collected.append(buffer, 0, n)
                }
                collected.toString()
            }
            val anchors = Regex("(?is)<a\\b([^>]*class=[\"'][^\"']*result__a[^\"']*[\"'][^>]*)>(.*?)</a>").findAll(html).take(6).toList()
            if (anchors.isEmpty()) return "لم أستطع استخراج نتائج بحث قابلة للعرض. جرّب عبارة أقصر أو افتح محرك البحث يدويًا."
            val snippets = Regex("(?is)<(?:a|div|td)[^>]*class=[\"'][^\"']*result__snippet[^\"']*[\"'][^>]*>(.*?)</(?:a|div|td)>").findAll(html).map { htmlEntity(stripTags(it.groupValues[1])).trim() }.toList()
            return buildString {
                append("نتائج البحث على الويب لعبارة: $q\n")
                anchors.forEachIndexed { i, m ->
                    val attrs = m.groupValues[1]
                    val href = Regex("(?i)href=[\"']([^\"']+)[\"']").find(attrs)?.groupValues?.get(1) ?: ""
                    val title = htmlEntity(stripTags(m.groupValues[2])).trim()
                    if (title.isNotBlank()) {
                        append("\n${i + 1}. $title\n$href\n")
                        snippets.getOrNull(i)?.takeIf { it.isNotBlank() }?.let { append(it.take(600)).append('\n') }
                    }
                }
                append("\nهذه مقتطفات وروابط من محرك بحث عام، وليست ملخصًا مولدًا بالذكاء الاصطناعي. تحقق من المصادر الأصلية.")
            }
        } catch (e: Exception) {
            return "تعذّر البحث على الإنترنت: ${e.message ?: e.javaClass.simpleName}. ما زال البحث المحلي يعمل دون اتصال."
        } finally { connection?.disconnect() }
    }

    private fun stripTags(value: String) = value.replace(Regex("(?is)<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()

    private fun createBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "LocalMind-Backup.zip")
        }
        startActivityForResult(intent, REQ_EXPORT)
    }

    private fun pickKnowledgePack() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
        }
        startActivityForResult(intent, REQ_IMPORT_PACK)
    }

    private fun importKnowledgePack(source: Uri) {
        var temp: File? = null
        try {
            runOnUiThread { Toast.makeText(this, "جارٍ استيراد حزمة المعرفة…", Toast.LENGTH_LONG).show() }
            val staging = File.createTempFile("localmind-import-", ".zip", cacheDir)
            temp = staging
            val input = contentResolver.openInputStream(source) ?: throw IllegalArgumentException("تعذّر فتح حزمة ZIP.")
            input.use { stream ->
                FileOutputStream(staging).use { output ->
                    val buffer = ByteArray(128 * 1024)
                    var total = 0L
                    while (true) {
                        val n = stream.read(buffer)
                        if (n < 0) break
                        total += n
                        require(total <= 2L * 1024L * 1024L * 1024L) { "حجم الحزمة أكبر من الحد الحالي البالغ 2 GB." }
                        output.write(buffer, 0, n)
                    }
                }
            }
            val stats = db.importPortablePack(staging)
            runOnUiThread {
                val msg = "اكتمل استيراد المعرفة. الذكريات: ${stats["notes"]}، الملفات: ${stats["documents"]}، المقاطع: ${stats["chunks"]}."
                addBubble(msg, false)
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "فشل استيراد حزمة المعرفة: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show() }
        } finally {
            temp?.delete()
        }
    }

    private fun exportBackup(destination: Uri) {
        try {
            // Checkpoint WAL frames into the main database before taking the snapshot.
            db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { }
            val sourceDb = getDatabasePath("localmind.db")
            require(sourceDb.isFile) { "لم أعثر على قاعدة البيانات المحلية." }
            contentResolver.openOutputStream(destination)?.use { output ->
                ZipOutputStream(output).use { zip ->
                    zip.putNextEntry(ZipEntry("data/localmind.db"))
                    sourceDb.inputStream().use { input -> input.copyTo(zip) }
                    zip.closeEntry()
                    val prefs = getSharedPreferences("settings", MODE_PRIVATE).all
                    zip.putNextEntry(ZipEntry("data/settings.txt"))
                    zip.write(prefs.entries.joinToString("\n") { "${it.key}=${it.value}" }.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    zip.putNextEntry(ZipEntry("BACKUP-README.txt"))
                    zip.write("LocalMind local-only backup. Includes raw Android SQLite DB, settings, and a cross-platform knowledge-pack with notes and indexed text. Original binary files are not embedded.".toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    writePortableKnowledgePack(zip)
                }
            } ?: throw IllegalStateException("تعذّر إنشاء ملف الوجهة.")
            runOnUiThread { Toast.makeText(this, "تم تصدير النسخة الاحتياطية.", Toast.LENGTH_LONG).show() }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "فشل النسخ الاحتياطي: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    /** Export the same streaming JSONL format used by the desktop Python application. */
    private fun writePortableKnowledgePack(zip: ZipOutputStream) {
        val database = db.readableDatabase
        fun scalar(sql: String): Int = database.rawQuery(sql, null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
        val packId = "lm-android-${System.currentTimeMillis()}"
        val manifest = JSONObject()
            .put("format", "localmind-portable-knowledge")
            .put("format_version", 1)
            .put("pack_id", packId)
            .put("created_at_utc", java.time.OffsetDateTime.now(java.time.ZoneOffset.UTC).toString())
            .put("counts", JSONObject().put("notes", scalar("SELECT COUNT(*) FROM notes"))
                .put("documents", scalar("SELECT COUNT(*) FROM documents"))
                .put("chunks", scalar("SELECT COUNT(*) FROM chunks")))
            .put("note", "Contains extracted and indexed text, not original binary documents. Original files can be imported again if needed.")
        zip.putNextEntry(ZipEntry("knowledge-pack/manifest.json"))
        zip.write(manifest.toString(2).toByteArray(Charsets.UTF_8))
        zip.closeEntry()
        writeJsonl(zip, "knowledge-pack/notes.jsonl", "SELECT id,title,content,created_at FROM notes ORDER BY id") { c ->
            JSONObject().put("id", c.getLong(0)).put("title", c.getString(1)).put("content", c.getString(2)).put("created_at", c.getString(3))
        }
        writeJsonl(zip, "knowledge-pack/documents.jsonl", "SELECT id,uri,title,bytes,indexed_at FROM documents ORDER BY id") { c ->
            JSONObject().put("id", c.getLong(0)).put("source", c.getString(1)).put("title", c.getString(2)).put("size_bytes", c.getLong(3)).put("indexed_at", c.getString(4))
        }
        writeJsonl(zip, "knowledge-pack/chunks.jsonl", "SELECT document_id,chunk_no,content FROM chunks ORDER BY document_id,chunk_no,id") { c ->
            JSONObject().put("document_id", c.getLong(0)).put("chunk_no", c.getInt(1)).put("content", c.getString(2))
        }
    }

    private fun writeJsonl(zip: ZipOutputStream, name: String, sql: String, map: (Cursor) -> JSONObject) {
        zip.putNextEntry(ZipEntry(name))
        db.readableDatabase.rawQuery(sql, null).use { cursor ->
            while (cursor.moveToNext()) {
                zip.write((map(cursor).toString() + "\n").toByteArray(Charsets.UTF_8))
            }
        }
        zip.closeEntry()
    }

    private fun showDocuments() {
        val docs = db.documentList()
        AlertDialog.Builder(this).setTitle("الملفات المفهرسة (${docs.size})")
            .setMessage(if (docs.isEmpty()) "لا توجد ملفات." else docs.take(100).joinToString("\n\n"))
            .setPositiveButton("إغلاق", null).show()
    }

    private fun showNotes() {
        val notes = db.notes()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(8)) }
        val text = TextView(this).apply { text = if (notes.isEmpty()) "لا توجد ذكريات محفوظة." else notes.joinToString("\n\n") { "#${it.id} — ${it.title}\n${it.content}" }; textSize = 14f; setTextColor(Color.DKGRAY) }
        box.addView(ScrollView(this).apply { addView(text) }, LinearLayout.LayoutParams(-1, dp(360)))
        val deleteInput = EditText(this).apply { hint = "رقم الذاكرة المراد حذفها"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        box.addView(deleteInput)
        AlertDialog.Builder(this).setTitle("الذاكرة المحلية (${notes.size})").setView(box)
            .setNegativeButton("إغلاق", null)
            .setPositiveButton("حذف الرقم المدخل") { _, _ ->
                val id = deleteInput.text.toString().toLongOrNull()
                if (id != null && db.forgetNote(id)) Toast.makeText(this, "حُذفت الذاكرة $id", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this, "لم يُحذف أي شيء؛ تحقق من الرقم", Toast.LENGTH_SHORT).show()
            }.show()
    }

    companion object {
        private const val REQ_FILES = 3101
        private const val REQ_FOLDER = 3102
        private const val REQ_EXPORT = 3103
        private const val REQ_IMPORT_PACK = 3104
    }
}
