package com.localmind.knowledge

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteStatement
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile
import java.text.Normalizer
import java.time.OffsetDateTime

class LocalDatabase(context: Context) : SQLiteOpenHelper(context, "localmind.db", null, 3) {
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL)")
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL)")
        db.execSQL("CREATE TABLE documents(id INTEGER PRIMARY KEY AUTOINCREMENT, uri TEXT NOT NULL UNIQUE, title TEXT NOT NULL, bytes INTEGER NOT NULL, indexed_at TEXT NOT NULL)")
        db.execSQL("CREATE TABLE chunks(id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE, chunk_no INTEGER NOT NULL, content TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_chunks_doc ON chunks(document_id, chunk_no)")
        createInvertedIndexTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(document_id, chunk_no)")
        if (oldVersion < 3) {
            createInvertedIndexTables(db)
            val docStatement = db.compileStatement("INSERT OR REPLACE INTO document_terms(document_id,term,term_count) VALUES(?,?,?)")
            try {
                db.rawQuery("SELECT id,title FROM documents", null).use { c ->
                    while (c.moveToNext()) indexTerms(c.getLong(0), c.getString(1), docStatement)
                }
            } finally { docStatement.close() }
            val chunkStatement = db.compileStatement("INSERT OR REPLACE INTO chunk_terms(chunk_id,term,term_count) VALUES(?,?,?)")
            try {
                db.rawQuery("SELECT id,content FROM chunks", null).use { c ->
                    while (c.moveToNext()) indexTerms(c.getLong(0), c.getString(1), chunkStatement)
                }
            } finally { chunkStatement.close() }
        }
    }

    private fun createInvertedIndexTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS document_terms(document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE, term TEXT NOT NULL, term_count INTEGER NOT NULL, PRIMARY KEY(document_id,term))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_document_terms_term ON document_terms(term)")
        db.execSQL("CREATE TABLE IF NOT EXISTS chunk_terms(chunk_id INTEGER NOT NULL REFERENCES chunks(id) ON DELETE CASCADE, term TEXT NOT NULL, term_count INTEGER NOT NULL, PRIMARY KEY(chunk_id,term))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_chunk_terms_term ON chunk_terms(term)")
    }

    private fun now() = OffsetDateTime.now().toString()

    fun addMessage(role: String, content: String) {
        writableDatabase.insert("messages", null, ContentValues().apply {
            put("role", role); put("content", content); put("created_at", now())
        })
    }

    fun recentMessages(limit: Int = 80): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery("SELECT role,content FROM messages ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) out.add(c.getString(0) to c.getString(1))
        }
        return out.reversed()
    }

    fun remember(title: String, content: String): Long = writableDatabase.insert("notes", null, ContentValues().apply {
        put("title", title.take(180)); put("content", content.take(20000)); put("created_at", now())
    })

    data class Note(val id: Long, val title: String, val content: String)
    fun notes(): List<Note> {
        val out = mutableListOf<Note>()
        readableDatabase.rawQuery("SELECT id,title,content FROM notes ORDER BY id DESC LIMIT 500", null).use { c ->
            while (c.moveToNext()) out.add(Note(c.getLong(0), c.getString(1), c.getString(2)))
        }
        return out
    }
    fun forgetNote(id: Long): Boolean = writableDatabase.delete("notes", "id=?", arrayOf(id.toString())) > 0

    data class Hit(val title: String, val uri: String, val chunkNo: Int, val content: String, val score: Double)

    fun indexText(uri: String, title: String, text: String, byteCount: Long): Int {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("documents", "uri=?", arrayOf(uri))
            val doc = ContentValues().apply {
                put("uri", uri); put("title", title.take(500)); put("bytes", byteCount); put("indexed_at", now())
            }
            val docId = db.insertOrThrow("documents", null, doc)
            db.compileStatement("INSERT OR REPLACE INTO document_terms(document_id,term,term_count) VALUES(?,?,?)").use { statement ->
                indexTerms(docId, title.take(500), statement)
            }
            val chunkStatement = db.compileStatement("INSERT OR REPLACE INTO chunk_terms(chunk_id,term,term_count) VALUES(?,?,?)")
            var n = 0
            try {
                val clean = text.trim()
                val width = 1600
                val overlap = 180
                var start = 0
                while (start < clean.length) {
                    val end = minOf(clean.length, start + width)
                    val part = clean.substring(start, end).trim()
                    if (part.isNotEmpty()) {
                        val chunkId = db.insertOrThrow("chunks", null, ContentValues().apply {
                            put("document_id", docId); put("chunk_no", n); put("content", part)
                        })
                        indexTerms(chunkId, part, chunkStatement)
                        n++
                    }
                    if (end == clean.length) break
                    start = end - overlap
                }
            } finally { chunkStatement.close() }
            db.setTransactionSuccessful()
            return n
        } finally { db.endTransaction() }
    }

    fun search(query: String, limit: Int = 5): List<Hit> {
        val terms = tokens(query).take(24)
        if (terms.isEmpty()) return emptyList()
        val placeholders = terms.joinToString(",") { "?" }
        val args = (terms + terms).toTypedArray()
        val hits = mutableListOf<Hit>()
        readableDatabase.rawQuery(
            "SELECT d.title,d.uri,c.chunk_no,c.content, " +
                "(COUNT(DISTINCT ct.term)+COUNT(DISTINCT dt.term)) AS matched " +
                "FROM chunks c JOIN documents d ON d.id=c.document_id " +
                "LEFT JOIN chunk_terms ct ON ct.chunk_id=c.id AND ct.term IN ($placeholders) " +
                "LEFT JOIN document_terms dt ON dt.document_id=d.id AND dt.term IN ($placeholders) " +
                "WHERE ct.term IS NOT NULL OR dt.term IS NOT NULL " +
                "GROUP BY c.id ORDER BY matched DESC,c.id DESC LIMIT 400",
            args
        ).use { c ->
            while (c.moveToNext()) {
                val title = c.getString(0); val uri = c.getString(1); val chunkNo = c.getInt(2); val content = c.getString(3)
                val hay = normalize("$title $content")
                val present = terms.filter { hay.contains(it) }
                if (present.isNotEmpty()) {
                    val coverage = present.size.toDouble() / terms.size
                    val density = present.sumOf { minOf(3, hay.split(it).size - 1) }.toDouble() / kotlin.math.sqrt(maxOf(1, hay.length).toDouble())
                    val phrase = if (normalize(query).isNotBlank() && hay.contains(normalize(query))) 2.0 else 0.0
                    hits.add(Hit(title, uri, chunkNo, content, coverage * 4 + density + phrase))
                }
            }
        }
        // Keep a compatibility fallback for any rows that predate a successful term-index migration.
        if (hits.isEmpty()) {
            val where = terms.joinToString(" OR ") { "lower(c.content) LIKE ? OR lower(d.title) LIKE ?" }
            val argsFallback = mutableListOf<String>()
            terms.forEach { argsFallback.add("%${it.lowercase()}%"); argsFallback.add("%${it.lowercase()}%") }
            readableDatabase.rawQuery(
                "SELECT d.title,d.uri,c.chunk_no,c.content FROM chunks c JOIN documents d ON d.id=c.document_id WHERE $where LIMIT 400",
                argsFallback.toTypedArray()
            ).use { c ->
                while (c.moveToNext()) {
                    val title = c.getString(0); val uri = c.getString(1); val chunkNo = c.getInt(2); val content = c.getString(3)
                    val hay = normalize("$title $content")
                    val present = terms.filter { hay.contains(it) }
                    if (present.isNotEmpty()) hits.add(Hit(title, uri, chunkNo, content, present.size.toDouble() / terms.size))
                }
            }
        }
        return hits.sortedByDescending { it.score }.take(limit.coerceIn(1, 100))
    }

    fun documentList(): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT title,uri,bytes FROM documents ORDER BY indexed_at DESC", null).use { c ->
            while (c.moveToNext()) out.add("${c.getString(0)} — ${c.getLong(2)} bytes\n${c.getString(1)}")
        }
        return out
    }

    fun counts(): Pair<Int, Int> {
        val docs = readableDatabase.rawQuery("SELECT COUNT(*) FROM documents", null).use { c -> c.moveToFirst(); c.getInt(0) }
        val notesCount = readableDatabase.rawQuery("SELECT COUNT(*) FROM notes", null).use { c -> c.moveToFirst(); c.getInt(0) }
        return docs to notesCount
    }

    /** Import the cross-platform JSONL pack emitted by desktop LocalMind Forge. */
    fun importPortablePack(zipPath: File): Map<String, Int> {
        ZipFile(zipPath).use { zip ->
            val required = listOf(
                "knowledge-pack/manifest.json",
                "knowledge-pack/notes.jsonl",
                "knowledge-pack/documents.jsonl",
                "knowledge-pack/chunks.jsonl"
            )
            require(required.all { zip.getEntry(it) != null }) {
                "هذا ZIP لا يحتوي على حزمة معرفة LocalMind قابلة للاستيراد."
            }
            val manifestEntry = zip.getEntry(required[0])
            require(manifestEntry.size in 1..(1024L * 1024L)) { "ملف بيان الحزمة غير صالح أو أكبر من اللازم." }
            val manifestText = zip.getInputStream(manifestEntry).bufferedReader(Charsets.UTF_8).use { it.readText() }
            val manifest = JSONObject(manifestText)
            require(manifest.optString("format") == "localmind-portable-knowledge" && manifest.optInt("format_version") == 1) {
                "صيغة حزمة المعرفة أو إصدارها غير مدعوم."
            }
            val packId = manifest.optString("pack_id", "imported").replace(Regex("[^A-Za-z0-9_-]"), "_").take(100).ifBlank { "imported" }
            val imported = mutableMapOf("notes" to 0, "documents" to 0, "chunks" to 0)
            val oldToNew = mutableMapOf<String, Long>()
            val db = writableDatabase
            db.beginTransaction()
            try {
                readJsonLines(zip, "knowledge-pack/notes.jsonl") { record ->
                    val title = record.optString("title", "معلومة").take(180)
                    val content = record.optString("content", "").take(20000)
                    if (content.isNotBlank()) {
                        val found = db.rawQuery("SELECT 1 FROM notes WHERE title=? AND content=? LIMIT 1", arrayOf(title, content)).use { it.moveToFirst() }
                        if (!found) {
                            db.insertOrThrow("notes", null, ContentValues().apply {
                                put("title", title.ifBlank { "معلومة" }); put("content", content)
                                put("created_at", record.optString("created_at").ifBlank { now() })
                            })
                            imported["notes"] = imported.getValue("notes") + 1
                        }
                    }
                }
                readJsonLines(zip, "knowledge-pack/documents.jsonl") { record ->
                    val oldId = record.optString("id", "")
                    if (oldId.isNotBlank()) {
                        val source = "localmind-pack://$packId/$oldId"
                        val title = record.optString("title", "مستند مستورد").take(500)
                        db.delete("documents", "uri=?", arrayOf(source))
                        val newId = db.insertOrThrow("documents", null, ContentValues().apply {
                            put("uri", source)
                            put("title", title)
                            put("bytes", record.optLong("size_bytes", 0L).coerceAtLeast(0L))
                            put("indexed_at", record.optString("indexed_at").ifBlank { now() })
                        })
                        oldToNew[oldId] = newId
                        db.compileStatement("INSERT OR REPLACE INTO document_terms(document_id,term,term_count) VALUES(?,?,?)").use { statement ->
                            indexTerms(newId, title, statement)
                        }
                        imported["documents"] = imported.getValue("documents") + 1
                    }
                }
                var pending = 0
                val chunkStatement = db.compileStatement("INSERT OR REPLACE INTO chunk_terms(chunk_id,term,term_count) VALUES(?,?,?)")
                try {
                    readJsonLines(zip, "knowledge-pack/chunks.jsonl") { record ->
                        val target = oldToNew[record.optString("document_id", "")]
                        val content = record.optString("content", "")
                        if (target != null && content.isNotBlank()) {
                            val boundedContent = content.take(500000)
                            val chunkId = db.insertOrThrow("chunks", null, ContentValues().apply {
                                put("document_id", target)
                                put("chunk_no", record.optInt("chunk_no", 0).coerceAtLeast(0))
                                put("content", boundedContent)
                            })
                            indexTerms(chunkId, boundedContent, chunkStatement)
                            imported["chunks"] = imported.getValue("chunks") + 1
                            pending++
                        }
                    }
                } finally { chunkStatement.close() }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            return imported
        }
    }

    private fun indexTerms(ownerId: Long, text: String, statement: SQLiteStatement) {
        val counts = tokens(text).groupingBy { it }.eachCount()
        for ((term, count) in counts) {
            statement.clearBindings()
            statement.bindLong(1, ownerId)
            statement.bindString(2, term)
            statement.bindLong(3, count.toLong())
            statement.executeInsert()
        }
    }

    private fun readJsonLines(zip: ZipFile, entryName: String, consume: (JSONObject) -> Unit) {
        val entry = zip.getEntry(entryName) ?: throw IllegalArgumentException("عنصر مفقود: $entryName")
        require(entry.size <= 2L * 1024L * 1024L * 1024L) { "ملف بيانات الحزمة أكبر من الحد المسموح." }
        zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { reader ->
            var lineNo = 0
            while (true) {
                val line = reader.readLine() ?: break
                lineNo++
                if (line.isBlank()) continue
                require(line.length <= 2_000_000) { "سجل كبير جدًا داخل $entryName عند السطر $lineNo" }
                val item = try { JSONObject(line) } catch (e: Exception) {
                    throw IllegalArgumentException("JSON غير صالح في $entryName، السطر $lineNo")
                }
                consume(item)
            }
        }
    }

    companion object {
        fun normalize(value: String): String {
            var s = Normalizer.normalize(value, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
            return s.replace("ـ", "").replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ٱ', 'ا').replace('ى', 'ي').lowercase()
        }
        fun tokens(value: String): List<String> {
            val stop = setOf("من", "الى", "إلى", "على", "في", "هل", "ما", "ماذا", "كيف", "هذا", "هذه", "the", "and", "or", "is", "are", "a", "an", "to", "of", "for", "in", "on")
            return Regex("[\\w\\u0600-\\u06FF]+")
                .findAll(normalize(value)).map { it.value }.filter { it.length >= 2 && it !in stop }.distinct().toList()
        }
    }
}
