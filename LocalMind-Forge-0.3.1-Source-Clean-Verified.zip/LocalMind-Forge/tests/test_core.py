from __future__ import annotations
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from core.database import LocalDatabase
from core.files import extract_text, index_file
from core.knowledge_agent import KnowledgeAgent, normalize, tokens
from core.backup import create_backup, verify_backup, import_knowledge_pack


class CoreTests(unittest.TestCase):
    def test_local_database_roundtrip_and_fts_messages(self):
        with tempfile.TemporaryDirectory() as d:
            db = LocalDatabase(Path(d) / "memory.sqlite3")
            db.add_message("user", "احتفظ بمعلومة عن قاعدة البيانات المحلية", "t1")
            db.add_message("assistant", "تم حفظ قاعدة البيانات المحلية", "t1")
            self.assertEqual(len(db.get_messages("t1")), 2)
            self.assertTrue(db.search_messages("قاعدة البيانات"))

    def test_database_chunk_index_and_search(self):
        with tempfile.TemporaryDirectory() as d:
            db = LocalDatabase(Path(d) / "memory.sqlite3")
            db.index_document(str(Path(d) / "manual.txt"), "manual.txt", "يجب تغيير زيت المحرك كل عشرة آلاف كيلومتر حسب دليل الصيانة.", 80, 0)
            hits = db.search_chunks("زيت المحرك الصيانة", limit=10)
            self.assertTrue(hits)
            self.assertIn("زيت المحرك", hits[0]["content"])

    def test_file_extraction_and_index(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "note.txt"
            p.write_text("LocalMind file extraction\nمعلومة عن قاعدة المعرفة", encoding="utf-8")
            self.assertIn("LocalMind", extract_text(p))
            db = LocalDatabase(Path(d) / "memory.sqlite3")
            chars, chunks = index_file(db, p)
            self.assertGreater(chars, 0)
            self.assertGreater(chunks, 0)
            self.assertTrue(db.search_chunks("قاعدة المعرفة"))

    def test_knowledge_answer_cites_local_source_without_model(self):
        with tempfile.TemporaryDirectory() as d:
            db = LocalDatabase(Path(d) / "memory.sqlite3")
            db.index_document(str(Path(d) / "vehicle.txt"), "vehicle.txt", "زيت المحرك يجب فحصه كل شهر وتغييره وفق جدول الصيانة.", 66, 0)
            agent = KnowledgeAgent(db, {"web_search_enabled": False})
            response = agent.answer("كيف أفحص زيت المحرك؟")
            self.assertIn("vehicle.txt", response)
            self.assertIn("زيت المحرك", response)

    def test_explicit_memory_and_delete(self):
        with tempfile.TemporaryDirectory() as d:
            db = LocalDatabase(Path(d) / "memory.sqlite3")
            agent = KnowledgeAgent(db, {"web_search_enabled": False})
            response = agent.answer("/remember تفضيل اللغة: أفضّل العربية")
            self.assertIn("حُفظت", response)
            self.assertEqual(db.list_notes()[0]["key"], "تفضيل اللغة")
            memory_id = db.list_notes()[0]["id"]
            self.assertIn("حُذفت", agent.answer(f"/forget {memory_id}"))
            self.assertFalse(db.list_notes())

    def test_disabled_web_is_respected(self):
        with tempfile.TemporaryDirectory() as d:
            db = LocalDatabase(Path(d) / "memory.sqlite3")
            agent = KnowledgeAgent(db, {"web_search_enabled": False})
            result = agent.answer("سؤال غير موجود في الملف المحلي")
            self.assertTrue("لا أملك مادة محلية كافية" in result or "لم أعثر" in result)

    def test_web_fallback_does_not_use_ai_api(self):
        with tempfile.TemporaryDirectory() as d:
            db = LocalDatabase(Path(d) / "memory.sqlite3")
            agent = KnowledgeAgent(db, {"web_search_enabled": True})
            with patch("core.knowledge_agent.web_search", return_value="نتائج بحث\n- عنوان\nالرابط: https://example.com"):
                response = agent.answer("معلومة عامة غير مخزنة محليًا")
            self.assertIn("https://example.com", response)
            self.assertIn("بحثت في الويب", response)


    def test_safe_file_creation_and_reading(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            db = LocalDatabase(root / "data" / "memory.sqlite3")
            workspace = root / "workspace"
            workspace.mkdir()
            agent = KnowledgeAgent(db, {"web_search_enabled": False, "workspace_path": str(workspace)})
            created = agent.answer("/create notes/idea.txt: فكرة محلية قابلة للحفظ")
            self.assertIn("تم إنشاء الملف", created)
            file_path = workspace / "notes" / "idea.txt"
            self.assertTrue(file_path.is_file())
            read_result = agent.answer(f"/read {file_path}")
            self.assertIn("فكرة محلية", read_result)
            blocked = agent.answer("/create ../outside.txt: ممنوع")
            self.assertIn("داخل مساحة العمل", blocked)
            self.assertFalse((root / "outside.txt").exists())

    def test_backup_integrity_and_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            database_path = root / "memory.sqlite3"
            db = LocalDatabase(database_path)
            db.remember("عنوان", "محتوى للنسخة الاحتياطية")
            config = root / "config.json"
            config.write_text('{"web_search_enabled": false}', encoding="utf-8")
            archive = create_backup(root / "backup.zip", database_path, config)
            manifest = verify_backup(archive)
            self.assertEqual(manifest["application"], "LocalMind Forge")
            self.assertIn("data/memory.sqlite3", manifest["files"])
            self.assertIn("data/config.json", manifest["files"])


    def test_portable_pack_import_across_databases(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            source = LocalDatabase(root / "source.sqlite3")
            source.remember("قواعد", "المعلومة تنتقل محليًا")
            source.index_document("C:/Docs/guide.txt", "guide.txt", "تخزن قاعدة البيانات المحلية مقاطع الملفات للبحث السريع.", 120, 0)
            zip_path = create_backup(root / "portable.zip", root / "source.sqlite3")
            target = LocalDatabase(root / "target.sqlite3")
            stats = import_knowledge_pack(zip_path, target)
            self.assertEqual(stats["notes"], 1)
            self.assertEqual(stats["documents"], 1)
            self.assertGreater(stats["chunks"], 0)
            self.assertTrue(target.search_chunks("قاعدة البيانات المحلية"))
            self.assertEqual(target.list_notes()[0]["value"], "المعلومة تنتقل محليًا")
            # Re-importing the same pack must replace document chunks and avoid duplicate notes.
            stats_again = import_knowledge_pack(zip_path, target)
            self.assertEqual(stats_again["notes"], 0)
            self.assertEqual(stats_again["documents"], 1)
            self.assertGreater(stats_again["chunks"], 0)
            self.assertEqual(len(target.list_documents()), 1)
            self.assertEqual(len(target.list_notes()), 1)

    def test_explicit_local_command_execution(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            db = LocalDatabase(root / "memory.sqlite3")
            workspace = root / "workspace"
            workspace.mkdir()
            agent = KnowledgeAgent(db, {"web_search_enabled": False, "workspace_path": str(workspace)})
            result = agent.answer("/exec echo LOCALMIND_CMD_OK")
            self.assertIn("LOCALMIND_CMD_OK", result)
            self.assertIn("رمز الخروج: 0", result)
            # A normal message containing the word /exec is not dispatched.
            result2 = agent.answer("اشرح لي ما معنى /exec دون تشغيله")
            self.assertNotIn("LOCALMIND_CMD_OK", result2)

    def test_unrelated_zip_is_rejected_as_knowledge_pack(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            bad_zip = root / "unrelated.zip"
            with zipfile.ZipFile(bad_zip, "w") as archive:
                archive.writestr("readme.txt", "not a LocalMind pack")
            target = LocalDatabase(root / "target.sqlite3")
            with self.assertRaisesRegex(ValueError, "حزمة معرفة LocalMind"):
                import_knowledge_pack(bad_zip, target)
            self.assertEqual(target.list_notes(), [])
            self.assertEqual(target.list_documents(), [])

    def test_arabic_normalization(self):
        self.assertEqual(normalize("إلى الأبد"), normalize("الي الابد"))
        self.assertIn("المعرفة", tokens("البحث في قاعدة المعرفة"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
